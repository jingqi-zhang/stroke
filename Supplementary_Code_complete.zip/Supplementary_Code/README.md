# Supplementary analysis code

This package accompanies the complete manuscript revision dated 22 September 2026.
It is an audit and reproduction source package, not a claim that public deposition has occurred.

## Inputs and paths

Scripts retain the original local paths to make provenance traceable. Before running, configure the root, raw data and output paths at the top of each script and in wrapper replacements. Do not run against a directory containing the only copy of your data. Inputs include:

* NHANES merged raw_data_merged.rds created from seven 2005 to 2018 cycles. Public source: https://wwwn.cdc.gov/nchs/nhanes/
* GSE16561 and GSE58294 supplied expression, platform annotation and sample metadata. Public source: GEO.
* GeneCards and gutMGene source exports; preserve the actual exported gene sets and their versions. Raw licensed exports are not redistributed in this package.
* GSE285659 annotated h5ad object and original counts, sample mapping and processing notebook.
* eQTLGen significant cis association file and allele frequencies, and MEGASTROKE GCST006908 harmonized summary statistics (29531354-GCST006908-HP_0002140.h.tsv.gz). Public sources: https://www.eqtlgen.org/ and https://www.ebi.ac.uk/gwas/studies/GCST006908.

Large raw files are not bundled. Numeric evidence is included for the estimates in the revised documents. Exact input checksums and a permanent public code URL should be added when preparing the public release.

## NHANES run order

Run 01_NHANES_revision_analysis.R first, then the flowchart and subgroup plotting scripts.
Run 05_full_table_and_harmonized_CRP_audit.R after the primary analysis. It also reads the saved bulk prediction files to calculate model performance intervals.
This final audit creates the full descriptive Table 1, harmonizes earlier CRP mg/dL values to mg/L, adjusts CRP models for cycle, and recomputes the secondary marker associations.
The old 04_NHANES_inflammation_revision.R is intentionally not included because it combined CRP units without this final correction.
The Table1_complete.csv and Inflammation_harmonized.csv in numeric_evidence/final are authoritative for the revised tables, not earlier summary tables.

## Bulk run order and source dependencies

Run training candidate selection, then the GSE16561 model wrapper and GSE58294 earliest time point wrapper. Both wrappers modify and evaluate source scripts. The previously omitted 07 and 08 source files are now included in source_dependencies. Configure wrapper source paths accordingly.
Run the repeated measurement script for limma time contrasts and the plotting scripts for revised panels.
The internal validation repeats penalty fitting but does not repeat supervised candidate discovery in each outer fold. Its AUC is conditional, not a fully nested pipeline estimate. The previously inspected GSE58294 cohort is not a prospectively untouched cohort.
The full model selected five nonzero coefficients from 15 candidates. Comparator models and all saved predictions are retained, including the failed constant external logistic predictions.

## Single cell run order

The stripped original notebook records preprocessing and retained trajectory code. Its historical module score and cell level inferential outputs are not the revised analyses.
Use audit_new_sc_genes.py and make_new_sc_panels.py with the annotated object for the new gene summaries, then redesign_sc2_paired_donor.py if desired.
Run cross_component_evidence.py after these summaries to reconstruct paired donor proportions and scores and the complete gutMGene record table.
Use an environment with scanpy, anndata, pandas, numpy, scipy and plotting dependencies. Original notebook also uses Harmony and scFates.
Three paired donors are the biological replicates. Pooled cell counts do not create additional independent subjects. No monocyte subtype stratified trajectory robustness analysis is claimed.

## MR run order

Run filter_eqtlgen_targets.py on the significant cis eQTL file, then run_eqtlgen_mr.py with the allele frequency and outcome files, then plot_mr_forest.py.
The final results use eQTLGen, not the earlier exploratory GTEx extract. One cis variant per gene is used, with approximate exposure effect scaling and first order Wald standard errors. No colocalization or multiple instrument pleiotropy sensitivity analysis was performed.
This is gene expression MR, not dietary fiber MR. No finding survives five gene Bonferroni correction.

## Software and public release

R analyses require survey, pROC, limma, glmnet and the packages imported in the included scripts. Graphics and enrichment require the relevant plotting and Bioconductor packages. The saved NHANES session information is included.
This package preserves source dependencies and reports unresolved limitations; it has not been tested as a fresh one command installation in a clean environment.
Deposit the package with documented input versions and a permanent identifier, or submit it as journal supplementary code for public release. The manuscript must not state that a repository already exists until that is true.
