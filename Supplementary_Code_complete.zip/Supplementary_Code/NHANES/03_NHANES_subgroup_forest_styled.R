suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(patchwork)
})

out_dir <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/NHANES_revision"
dat <- read.csv(file.path(out_dir, "Supplementary_Table2_revised.csv"), stringsAsFactors = FALSE)

group_map <- c(
  age_group = "Age group",
  diabetes = "Diabetes",
  hypertension = "Hypertension",
  obesity = "Obesity (BMI)",
  sex = "Sex"
)
stratum_map <- c(
  "Under 60 years" = "Under 60 years",
  "60 years or older" = "60 years or older",
  "No" = "No", "Yes" = "Yes", "Not obese" = "Not obese",
  "Obese" = "Obese", "Male" = "Male", "Female" = "Female"
)

order_rows <- data.frame(
  subgroup = c("age_group", "age_group", "diabetes", "diabetes", "hypertension",
               "hypertension", "obesity", "obesity", "sex", "sex"),
  stratum = c("Under 60 years", "60 years or older", "No", "Yes", "No", "Yes",
              "Not obese", "Obese", "Male", "Female"),
  y = c(14, 13, 11, 10, 8, 7, 5, 4, 2, 1)
)
dat <- order_rows %>% left_join(dat, by = c("subgroup", "stratum")) %>%
  mutate(group_label = unname(group_map[subgroup]),
         stratum_label = unname(stratum_map[stratum]),
         result = sprintf("%.2f (%.2f to %.2f)", OR, LCI, UCI))

groups <- dat %>% group_by(subgroup, group_label) %>%
  summarise(ymax = max(y) + 0.72, ymin = min(y) - 0.72,
            ytitle = max(y) + 0.45, pint = first(P_interaction), .groups = "drop")
groups$shade <- groups$subgroup %in% c("age_group", "hypertension", "sex")

shade_fill <- "#F3EEEE"
accent <- "#8E3B2F"

base_theme <- theme_void(base_size = 11) +
  theme(plot.margin = margin(5, 3, 5, 3), text = element_text(family = "sans"))

p_left <- ggplot() +
  geom_rect(data = subset(groups, shade),
            aes(xmin = 0, xmax = 1, ymin = ymin, ymax = ymax), fill = shade_fill) +
  geom_text(data = groups, aes(x = 0.02, y = ytitle, label = group_label),
            hjust = 0, vjust = 1, fontface = "bold", size = 4.2) +
  geom_text(data = dat, aes(x = 0.12, y = y, label = stratum_label),
            hjust = 0, size = 4.0) +
  annotate("text", x = 0.02, y = 16.05, label = "Subgroup", hjust = 0,
           fontface = "bold", color = accent, size = 4.7) +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.1, 16.4), clip = "off") + base_theme

p_mid <- ggplot(dat, aes(x = OR, y = y)) +
  geom_vline(xintercept = 1, linetype = "dashed", color = accent, linewidth = 0.65) +
  geom_errorbar(aes(xmin = LCI, xmax = UCI), orientation = "y", width = 0.16,
                color = accent, linewidth = 0.65) +
  geom_point(shape = 18, size = 3.0, color = accent) +
  scale_x_log10(limits = c(0.38, 1.12), breaks = c(0.4, 0.5, 0.7, 1.0),
                labels = c("0.4", "0.5", "0.7", "1.0")) +
  scale_y_continuous(limits = c(0.1, 16.4), expand = c(0, 0)) +
  annotate("text", x = 0.66, y = 16.05, label = "OR (95% CI)",
           fontface = "bold", color = accent, size = 4.7) +
  annotate("text", x = 0.43, y = 0.25, label = "Lower odds", hjust = 0,
           fontface = "italic", size = 3.5) +
  annotate("text", x = 1.075, y = 0.25, label = "Higher odds", hjust = 1,
           fontface = "italic", size = 3.5) +
  theme_classic(base_size = 11) +
  theme(axis.title = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank(),
        axis.line.y = element_blank(), axis.line.x = element_line(linewidth = 0.5),
        panel.grid.major.x = element_line(color = "#ECECEC", linewidth = 0.45),
        panel.grid.minor = element_blank(), plot.margin = margin(5, 3, 5, 3))

p_right <- ggplot() +
  geom_rect(data = subset(groups, shade),
            aes(xmin = 0, xmax = 1, ymin = ymin, ymax = ymax), fill = shade_fill) +
  geom_text(data = dat, aes(x = 0.02, y = y, label = result), hjust = 0, size = 3.9) +
  geom_text(data = groups,
            aes(x = 0.97, y = ytitle, label = sprintf("P = %.3f", pint)),
            hjust = 1, vjust = 1, fontface = "italic", color = accent, size = 3.8) +
  annotate("text", x = 0.02, y = 16.05, label = "OR (95% CI)", hjust = 0,
           fontface = "bold", color = accent, size = 4.7) +
  annotate("text", x = 0.97, y = 16.05, label = "P for interaction", hjust = 1,
           fontface = "bold", color = accent, size = 4.35) +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.1, 16.4), clip = "off") + base_theme

combined <- p_left + p_mid + p_right + plot_layout(widths = c(1.15, 1.65, 1.55))

ggsave(file.path(out_dir, "Figure_subgroup_styled.png"), combined,
       width = 10.2, height = 10.6, dpi = 600, bg = "white")
ggsave(file.path(out_dir, "Figure_subgroup_styled.tiff"), combined,
       width = 10.2, height = 10.6, dpi = 600, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "Figure_subgroup_styled.pdf"), combined,
       width = 10.2, height = 10.6, device = cairo_pdf, bg = "white")

cat("Styled subgroup forest plot created in", out_dir, "\n")
