options(survey.lonely.psu='adjust')
suppressPackageStartupMessages({library(survey);library(pROC)})
root <- 'C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88'
out <- file.path(root,'outputs/complete_revision/evidence')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
d <- readRDS(file.path(root,'outputs/NHANES_revision/primary_day1_analysis_data.rds'))
raw <- readRDS('C:/Users/13918/Desktop/Nhanse/output/raw_data_merged.rds')
j <- match(d$SEQN,raw$SEQN)
d$crp_mgL <- ifelse(!is.na(raw$LBXHSCRP[j]),raw$LBXHSCRP[j],10*raw$LBXCRP[j])
d$fiber_density <- d$fiber_day1/d$kcal_day1*1000
d$NLR <- ifelse(d$lymphocyte>0,d$neutrophil/d$lymphocyte,NA)
d$MLR <- ifelse(d$lymphocyte>0,d$monocyte/d$lymphocyte,NA)
d$SIRI <- ifelse(d$lymphocyte>0,d$neutrophil*d$monocyte/d$lymphocyte,NA)
des <- svydesign(ids=~SDMVPSU,strata=~SDMVSTRA,weights=~diet_weight,nest=TRUE,data=d)
groups <- list(Overall=des,No_stroke=subset(des,stroke==0),Stroke=subset(des,stroke==1))
fp <- function(p) ifelse(is.na(p),'Not tested',ifelse(p<.001,'<0.001',sprintf('%.3f',p)))
rows <- list(); numeric <- list()
add <- function(label,values,p='',kind='data') rows[[length(rows)+1]] <<- data.frame(Characteristic=label,Overall=values[1],No_stroke=values[2],Stroke=values[3],P_value=p,kind=kind)
add('Unweighted number of participants',sapply(groups,function(z)format(nrow(z$variables),big.mark=',')))
continuous <- c(age='Age, years, mean (SD)',pir='Poverty to income ratio, median [IQR]',bmi='BMI, kg/m2, median [IQR]',fiber_day1='Day 1 fiber, g/day, median [IQR]',fiber_density='Day 1 fiber density, g/1000 kcal, median [IQR]',kcal_day1='Day 1 energy, kcal/day, median [IQR]')
catvars <- c(sex='Sex',race='Race and ethnicity',edu='Education',hypertension='Hypertension',diabetes='Diabetes',smoking='Smoking',alcohol='Alcohol use',physical_active='Physical activity')
cont <- function(v,label){
  vals <- sapply(groups,function(z){
    f <- reformulate(v)
    if(v=='age') sprintf('%.2f (%.2f)',coef(svymean(f,z,na.rm=TRUE))[1],sqrt(coef(svyvar(f,z,na.rm=TRUE))[1])) else {
      q <- as.numeric(coef(svyquantile(f,z,c(.25,.5,.75),ci=FALSE,na.rm=TRUE)))
      sprintf('%.2f [%.2f, %.2f]',q[2],q[1],q[3])
    }
  })
  test <- if(v=='age') svyttest(reformulate('stroke',response=v),des) else svyranktest(reformulate('stroke',response=v),des,test='wilcoxon')
  add(label,vals,fp(test$p.value))
  miss <- sapply(groups,function(z)sum(is.na(z$variables[[v]])))
  if(any(miss>0)) add('  Missing, unweighted n',as.character(miss))
}
cont('age',continuous['age'])
for(v in names(catvars)) {
  test <- svychisq(reformulate(c(v,'stroke')),des,statistic='F')
  add(catvars[v],rep('',3),fp(test$p.value),'group')
  for(lv in levels(d[[v]])) {
    vals <- sapply(groups,function(z){
      z$variables$.ind <- as.numeric(z$variables[[v]]==lv)
      est <- as.numeric(coef(svymean(~.ind,z,na.rm=TRUE)))*100
      sprintf('%s (%.1f)',format(sum(z$variables[[v]]==lv,na.rm=TRUE),big.mark=','),est)
    })
    add(paste0('  ',lv),vals)
  }
  miss <- sapply(groups,function(z)sum(is.na(z$variables[[v]])))
  if(any(miss>0)) add('  Missing, unweighted n',as.character(miss))
}
for(v in setdiff(names(continuous),'age')) cont(v,continuous[v])
add('Inflammatory markers in available participants',rep('',3),'','group')
for(v in c('NLR','MLR','SIRI','crp_mgL')) cont(v,paste0(ifelse(v=='crp_mgL','CRP, mg/L',v),', median [IQR]'))
tab <- do.call(rbind,rows)
write.csv(tab,file.path(out,'Table1_complete.csv'),row.names=FALSE)
covars <- c('age','sex','race','edu','pir','bmi','hypertension','diabetes','smoking','alcohol','physical_active','kcal_day1')
fitmarker <- function(v,cycle_adjust=FALSE){
  x <- subset(d,is.finite(d[[v]]) & d[[v]]>0)
  x$log_marker <- log(x[[v]])
  # Consistent physical units; cycle adjustment for CRP assay-era variation.
  x$weight_marker <- x$WTDRD1/length(unique(x$cycle))
  dd <- svydesign(ids=~SDMVPSU,strata=~SDMVSTRA,weights=~weight_marker,nest=TRUE,data=x)
  f <- reformulate(c('log_fiber',covars,if(cycle_adjust)'factor(cycle)'),response='log_marker')
  fit <- svyglm(f,dd); cc<-confint(fit,'log_fiber');sm<-coef(summary(fit))
  data.frame(marker=v,beta=coef(fit)['log_fiber'],LCI=cc[1],UCI=cc[2],P=sm['log_fiber',ncol(sm)],n=nrow(model.frame(fit)),cycles=paste(unique(x$cycle),collapse='; '),cycle_adjusted=cycle_adjust)
}
infl <- do.call(rbind,c(lapply(c('NLR','MLR','SIRI'),fitmarker),list(fitmarker('crp_mgL',TRUE))))
write.csv(infl,file.path(out,'Inflammation_harmonized.csv'),row.names=FALSE)
audit <- data.frame(cycle=sort(unique(d$cycle)))
audit$n_CRP <- sapply(audit$cycle,function(cy)sum(!is.na(d$crp_mgL[d$cycle==cy])))
write.csv(audit,file.path(out,'CRP_cycle_availability.csv'),row.names=FALSE)
saveRDS(d,file.path(out,'table1_audit_data.rds'))
# Recalculate confidence intervals for every existing model prediction without changing models.
paths <- c(Internal=file.path(root,'outputs/bulk_revision/GSE16561_training_model/GSE16561_ML_focus_loocv_predictions.csv'),External=file.path(root,'outputs/bulk_revision/GSE58294_3h_external_validation/GSE58294_external_focus_predictions.csv'))
aucs<-list()
for(nm in names(paths)){
 p<-read.csv(paths[nm]);for(m in c('LASSO','RF','Logistic')){
 rr<-roc(p$Group,p[[m]],levels=c('Control','Stroke'),direction='<',quiet=TRUE);ci<-ci.auc(rr)
 aucs[[length(aucs)+1]]<-data.frame(dataset=nm,model=m,n=nrow(p),stroke=sum(p$Group=='Stroke'),control=sum(p$Group=='Control'),AUC=as.numeric(auc(rr)),LCI=ci[1],UCI=ci[3])
 }}
write.csv(do.call(rbind,aucs),file.path(out,'Model_performance_audit.csv'),row.names=FALSE)
cat('Table 1 rows:',nrow(tab),'\n');print(infl);print(do.call(rbind,aucs));print(audit)
