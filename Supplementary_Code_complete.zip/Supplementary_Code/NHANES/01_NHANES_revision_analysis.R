options(survey.lonely.psu = "adjust")
options(error = function() { traceback(8); quit(status = 1) })
suppressPackageStartupMessages({
  library(haven)
  library(survey)
  library(splines)
  library(dplyr)
  library(ggplot2)
})

data_dir <- "C:/Users/13918/Desktop/Nhanse"
base_file <- file.path(data_dir, "output", "raw_data_merged.rds")
out_dir <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/NHANES_revision"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

cycles <- data.frame(
  suffix = LETTERS[4:10],
  cycle = c("2005-2006", "2007-2008", "2009-2010", "2011-2012",
            "2013-2014", "2015-2016", "2017-2018")
)

read_cycle <- function(suffix, cycle) {
  d1 <- zap_labels(read_xpt(file.path(data_dir, paste0("DR1TOT_", suffix, ".XPT"))))
  d2 <- zap_labels(read_xpt(file.path(data_dir, paste0("DR2TOT_", suffix, ".XPT"))))
  keep1 <- intersect(c("SEQN", "WTDRD1", "WTDR2D", "DR1TKCAL", "DR1TFIBE"), names(d1))
  keep2 <- intersect(c("SEQN", "DR2TKCAL", "DR2TFIBE"), names(d2))
  x <- merge(d1[keep1], d2[keep2], by = "SEQN", all.x = TRUE)
  required <- c("WTDRD1", "WTDR2D", "DR1TKCAL", "DR1TFIBE", "DR2TKCAL", "DR2TFIBE")
  for (nm in setdiff(required, names(x))) x[[nm]] <- NA_real_
  x$cycle_diet <- cycle
  x$fiber_day1 <- x$DR1TFIBE
  x$kcal_day1 <- x$DR1TKCAL
  x$fiber_2day <- rowMeans(cbind(x$DR1TFIBE, x$DR2TFIBE), na.rm = TRUE)
  x$kcal_2day <- rowMeans(cbind(x$DR1TKCAL, x$DR2TKCAL), na.rm = TRUE)
  x$two_day_complete <- !is.na(x$DR1TFIBE) & !is.na(x$DR2TFIBE) &
    !is.na(x$WTDR2D) & x$WTDR2D > 0
  x[c("SEQN", "cycle_diet", "WTDRD1", "WTDR2D", "fiber_day1", "kcal_day1",
      "fiber_2day", "kcal_2day", "two_day_complete")]
}

diet <- dplyr::bind_rows(Map(read_cycle, cycles$suffix, cycles$cycle))
raw <- readRDS(base_file)
base <- raw %>% transmute(
  SEQN, cycle, SDMVPSU, SDMVSTRA,
  stroke = case_when(MCQ160F == 1 ~ 1, MCQ160F == 2 ~ 0, TRUE ~ NA_real_),
  age = RIDAGEYR,
  sex = factor(RIAGENDR, levels = c(1, 2), labels = c("Male", "Female")),
  race = factor(case_when(
    RIDRETH1 == 1 ~ "Mexican American", RIDRETH1 == 2 ~ "Other Hispanic",
    RIDRETH1 == 3 ~ "Non Hispanic White", RIDRETH1 == 4 ~ "Non Hispanic Black",
    RIDRETH1 == 5 ~ "Other Race", TRUE ~ NA_character_),
    levels = c("Non Hispanic White", "Non Hispanic Black", "Mexican American",
               "Other Hispanic", "Other Race")),
  edu = factor(case_when(DMDEDUC2 %in% c(1, 2) ~ 1, DMDEDUC2 == 3 ~ 2,
                         DMDEDUC2 %in% c(4, 5) ~ 3, TRUE ~ NA_real_),
               levels = 1:3, labels = c("Below high school", "High school", "Above high school")),
  pir = INDFMPIR,
  bmi = BMXBMI,
  hypertension = factor(case_when(BPQ020 == 1 ~ "Yes", BPQ020 == 2 ~ "No",
                                   TRUE ~ NA_character_), levels = c("No", "Yes")),
  diabetes = factor(case_when(DIQ010 == 1 ~ "Yes", DIQ010 %in% c(2, 3) ~ "No",
                               TRUE ~ NA_character_), levels = c("No", "Yes")),
  smoking = factor(case_when(
    SMQ020 == 2 ~ "Never", SMQ020 == 1 & SMQ040 %in% c(1, 2) ~ "Current",
    SMQ020 == 1 & SMQ040 == 3 ~ "Former", TRUE ~ NA_character_),
    levels = c("Never", "Former", "Current")),
  alcohol = factor(case_when(
    ALQ101 == 2 | ALQ110 == 2 | ALQ111 == 2 ~ "None",
    !is.na(ALQ130) & ((RIAGENDR == 1 & ALQ130 > 2) | (RIAGENDR == 2 & ALQ130 > 1)) ~ "Heavy",
    !is.na(ALQ130) & ALQ130 >= 0 ~ "Moderate",
    TRUE ~ "Unknown"), levels = c("None", "Moderate", "Heavy", "Unknown")),
  physical_active = factor(case_when(
    cycle == "2005-2006" & (PAD200 == 1 | PAD320 == 1) ~ "Active",
    cycle == "2005-2006" & PAD200 == 2 & PAD320 == 2 ~ "Inactive",
    cycle != "2005-2006" & (PAQ605 == 1 | PAQ620 == 1 | PAQ650 == 1 | PAQ665 == 1) ~ "Active",
    cycle != "2005-2006" & PAQ605 == 2 & PAQ620 == 2 & PAQ650 == 2 & PAQ665 == 2 ~ "Inactive",
    TRUE ~ NA_character_), levels = c("Inactive", "Active")),
  hscrp = coalesce(LBXHSCRP, LBXCRP),
  neutrophil = LBDNENO, lymphocyte = LBDLYMNO, monocyte = LBDMONO,
  platelet = LBXPLTSI
)
dat <- merge(base, diet, by = "SEQN", all.x = TRUE)

# Primary population: adults with valid Day-1 recall and stroke status. Inflammatory
# biomarkers are deliberately not required for the primary association analysis.
primary <- subset(dat, age >= 20 & !is.na(stroke) & !is.na(fiber_day1) &
                    !is.na(kcal_day1) & kcal_day1 >= 500 & kcal_day1 <= 8000 &
                    !is.na(WTDRD1) & WTDRD1 > 0)
primary$log_fiber <- log(primary$fiber_day1 + 0.1)
primary$diet_weight <- primary$WTDRD1 / nrow(cycles)

# Two-day sensitivity population and weight.
two_day <- subset(dat, age >= 20 & !is.na(stroke) & two_day_complete &
                    !is.na(fiber_2day) & !is.na(kcal_2day) &
                    kcal_2day >= 500 & kcal_2day <= 8000)
two_day$log_fiber <- log(two_day$fiber_2day + 0.1)
two_day$diet_weight <- two_day$WTDR2D / nrow(cycles)

make_design <- function(x) {
  svydesign(ids = ~SDMVPSU, strata = ~SDMVSTRA, weights = ~diet_weight,
            nest = TRUE, data = x)
}
d1_design <- make_design(primary)
d2_design <- make_design(two_day)

covars <- list(
  "Model 1 (crude)" = character(),
  "Model 2" = c("age", "sex", "race", "edu", "pir"),
  "Model 3" = c("age", "sex", "race", "edu", "pir", "bmi", "hypertension",
                "diabetes", "smoking", "alcohol", "physical_active", "kcal_day1")
)

fit_models <- function(design, exposure, kcal_name, analysis_name) {
  ans <- lapply(names(covars), function(lbl) {
    cv <- covars[[lbl]]
    cv[cv == "kcal_day1"] <- kcal_name
    f <- reformulate(c(exposure, cv), response = "stroke")
    fit <- svyglm(f, design = design, family = quasibinomial())
    sm <- coef(summary(fit))[exposure, ]
    ci <- confint(fit, exposure)
    data.frame(analysis = analysis_name, model = lbl, exposure = exposure,
               OR = exp(coef(fit)[exposure]), LCI = exp(ci[1]), UCI = exp(ci[2]),
               P = sm[ncol(coef(summary(fit)))], n = nrow(model.frame(fit)))
  })
  do.call(rbind, ans)
}

main_results <- rbind(
  fit_models(d1_design, "log_fiber", "kcal_day1", "Primary: Day 1, WTDRD1/7"),
  fit_models(d2_design, "log_fiber", "kcal_2day", "Sensitivity: 2-day mean, WTDR2D/7")
)
write.csv(main_results, file.path(out_dir, "Table2_revised_weighted_models.csv"), row.names = FALSE)

# Weighted quartiles and trend test for the primary exposure.
qcut <- as.numeric(coef(svyquantile(~fiber_day1, d1_design, c(0, .25, .5, .75, 1),
                                    na.rm = TRUE, ci = FALSE)))
qcut[1] <- qcut[1] - 1e-8
qcut[5] <- qcut[5] + 1e-8
d1_design <- update(d1_design,
  fiber_quartile = cut(fiber_day1, qcut, labels = paste0("Q", 1:4), include.lowest = TRUE),
  fiber_quartile_rank = as.numeric(cut(fiber_day1, qcut, labels = 1:4, include.lowest = TRUE)))
quartile_fit <- svyglm(stroke ~ fiber_quartile + age + sex + race + edu + pir + bmi +
  hypertension + diabetes + smoking + alcohol + physical_active + kcal_day1,
  design = d1_design, family = quasibinomial())
quartile_ci <- confint(quartile_fit)
quartile_rows <- grep("^fiber_quartile", names(coef(quartile_fit)))
quartile_results <- data.frame(
  quartile = paste0("Q", 1:4),
  OR = c(1, exp(coef(quartile_fit)[quartile_rows])),
  LCI = c(1, exp(quartile_ci[quartile_rows, 1])),
  UCI = c(1, exp(quartile_ci[quartile_rows, 2])),
  P = c(NA, coef(summary(quartile_fit))[quartile_rows, ncol(coef(summary(quartile_fit)))])
)
trend_fit <- svyglm(stroke ~ fiber_quartile_rank + age + sex + race + edu + pir + bmi +
  hypertension + diabetes + smoking + alcohol + physical_active + kcal_day1,
  design = d1_design, family = quasibinomial())
quartile_results$P_trend <- c(coef(summary(trend_fit))["fiber_quartile_rank",
  ncol(coef(summary(trend_fit)))], rep(NA, 3))
write.csv(quartile_results, file.path(out_dir, "Supplementary_Table1_revised.csv"), row.names = FALSE)

# Subgroup estimates and interaction tests.
primary$age_group <- factor(ifelse(primary$age < 60, "Under 60 years", "60 years or older"))
primary$obesity <- factor(ifelse(primary$bmi >= 30, "Obese", "Not obese"))
d1_design <- make_design(primary)
subgroup_vars <- c("sex", "age_group", "hypertension", "diabetes", "obesity")
full_covars <- c("age", "sex", "race", "edu", "pir", "bmi", "hypertension", "diabetes",
                 "smoking", "alcohol", "physical_active", "kcal_day1")
subgroup_results <- do.call(rbind, lapply(subgroup_vars, function(v) {
  levels_v <- levels(droplevels(primary[[v]]))
  interaction_covars <- setdiff(full_covars, c(v, if (v == "age_group") "age" else NULL,
                                               if (v == "obesity") "bmi" else NULL))
  int_formula <- reformulate(c(paste0("log_fiber*", v), interaction_covars), response = "stroke")
  int_fit <- svyglm(int_formula, design = d1_design, family = quasibinomial())
  p_int <- regTermTest(int_fit, as.formula(paste0("~log_fiber:", v)))$p
  do.call(rbind, lapply(levels_v, function(lv) {
    sub <- subset(d1_design, d1_design$variables[[v]] == lv)
    cv <- setdiff(full_covars, c(v, if (v == "age_group") "age" else NULL,
                                if (v == "obesity") "bmi" else NULL))
    fit <- svyglm(reformulate(c("log_fiber", cv), response = "stroke"),
                  design = sub, family = quasibinomial())
    ci <- confint(fit, "log_fiber")
    used <- model.frame(fit)
    data.frame(subgroup = v, stratum = lv, n_total = nrow(used),
               n_stroke = sum(used$stroke == 1), OR = exp(coef(fit)["log_fiber"]),
               LCI = exp(ci[1]), UCI = exp(ci[2]),
               P = coef(summary(fit))["log_fiber", ncol(coef(summary(fit)))], P_interaction = p_int)
  }))
}))
write.csv(subgroup_results, file.path(out_dir, "Supplementary_Table2_revised.csv"), row.names = FALSE)

# Survey-weighted Table 1 summaries by stroke status.
weighted_mean <- function(v, design) {
  z <- svyby(as.formula(paste0("~", v)), ~stroke, design, svymean, na.rm = TRUE, vartype = "ci")
  data.frame(variable = v, level = "Mean", stroke = z$stroke,
             estimate = z[[2]], ci_low = z[[3]], ci_high = z[[4]])
}
weighted_cat <- function(v, design) {
  lv <- unique(na.omit(design$variables[[v]]))
  if (is.factor(design$variables[[v]])) lv <- levels(droplevels(design$variables[[v]]))
  do.call(rbind, lapply(lv, function(level) {
    ind <- as.numeric(as.character(design$variables[[v]]) == as.character(level))
    dtmp <- update(design, .indicator = ind)
    z <- svyby(~.indicator, ~stroke, dtmp, svymean, na.rm = TRUE, vartype = "ci")
    data.frame(variable = v, level = as.character(level), stroke = z$stroke,
               estimate = z[[2]], ci_low = z[[3]], ci_high = z[[4]])
  }))
}
continuous <- c("age", "pir", "bmi", "fiber_day1", "kcal_day1")
categorical <- c("sex", "race", "edu", "hypertension", "diabetes", "smoking",
                 "alcohol", "physical_active")
tab1_cont <- do.call(rbind, lapply(continuous, weighted_mean, design = d1_design))
tab1_cat <- do.call(rbind, lapply(categorical, weighted_cat, design = d1_design))
write.csv(tab1_cont, file.path(out_dir, "Table1_weighted_continuous.csv"), row.names = FALSE)
write.csv(tab1_cat, file.path(out_dir, "Table1_weighted_categorical.csv"), row.names = FALSE)

# RCS-equivalent survey spline: natural spline terms are fitted inside svyglm.
rcs_formula <- stroke ~ ns(fiber_day1, df = 3) + age + sex + race + edu + pir + bmi +
  hypertension + diabetes + smoking + alcohol + physical_active + kcal_day1
rcs_fit <- svyglm(rcs_formula, design = d1_design, family = quasibinomial())
rcs_test <- regTermTest(rcs_fit, ~ns(fiber_day1, df = 3))
linear_formula <- update(rcs_formula, . ~ . - ns(fiber_day1, df = 3) + fiber_day1)
linear_fit <- svyglm(linear_formula, design = d1_design, family = quasibinomial())
nonlinear_test <- anova(linear_fit, rcs_fit, method = "Wald")
nonlinear_p <- nonlinear_test$p
capture.output(summary(rcs_fit), rcs_test, nonlinear_test,
               file = file.path(out_dir, "RCS_survey_model.txt"))

# Survey weighted spline curve as odds ratios referenced to the weighted median.
x_grid <- seq(as.numeric(coef(svyquantile(~fiber_day1, d1_design, .01, ci = FALSE))),
              as.numeric(coef(svyquantile(~fiber_day1, d1_design, .99, ci = FALSE))), length.out = 160)
ref_x <- as.numeric(coef(svyquantile(~fiber_day1, d1_design, .5, ci = FALSE)))
mf <- model.frame(rcs_fit)
reference <- data.frame(
  fiber_day1 = x_grid, age = median(mf$age, na.rm = TRUE), sex = levels(mf$sex)[1],
  race = levels(mf$race)[1], edu = levels(mf$edu)[1], pir = median(mf$pir, na.rm = TRUE),
  bmi = median(mf$bmi, na.rm = TRUE), hypertension = levels(mf$hypertension)[1],
  diabetes = levels(mf$diabetes)[1], smoking = levels(mf$smoking)[1],
  alcohol = levels(mf$alcohol)[1], physical_active = levels(mf$physical_active)[1],
  kcal_day1 = median(mf$kcal_day1, na.rm = TRUE))
for (v in c("sex", "race", "edu", "hypertension", "diabetes", "smoking", "alcohol", "physical_active")) {
  reference[[v]] <- factor(reference[[v]], levels = levels(mf[[v]]))
}
X <- model.matrix(delete.response(terms(rcs_fit)), reference)
reference$fiber_day1 <- ref_x
Xref <- model.matrix(delete.response(terms(rcs_fit)), reference[1, , drop = FALSE])
C <- sweep(X, 2, Xref[1, ], "-")
eta <- as.numeric(C %*% coef(rcs_fit))
se <- sqrt(rowSums((C %*% vcov(rcs_fit)) * C))
rcs_plot_data <- data.frame(fiber = x_grid, OR = exp(eta), LCI = exp(eta - 1.96 * se),
                            UCI = exp(eta + 1.96 * se))
write.csv(rcs_plot_data, file.path(out_dir, "Figure_RCS_plot_data.csv"), row.names = FALSE)
p_rcs <- ggplot(rcs_plot_data, aes(fiber, OR)) +
  geom_ribbon(aes(ymin = LCI, ymax = UCI), fill = "#BFE8C3", alpha = .65) +
  geom_line(color = "#1F9D3A", linewidth = 1) + geom_hline(yintercept = 1, linetype = 2) +
  labs(x = "Dietary fiber intake in grams per day", y = "Odds ratio for self reported stroke",
       subtitle = sprintf("Overall P = %.3f   Nonlinear P = %.3f", rcs_test$p, nonlinear_p)) +
  theme_classic(base_size = 11)
write.csv(data.frame(overall_p = rcs_test$p, nonlinear_p = nonlinear_p),
          file.path(out_dir, "RCS_tests_revised.csv"), row.names = FALSE)
ggsave(file.path(out_dir, "Figure_RCS_revised.png"), p_rcs, width = 6.4, height = 5, dpi = 600)
ggsave(file.path(out_dir, "Figure_RCS_revised.pdf"), p_rcs, width = 6.4, height = 5)

subgroup_results$label <- paste(subgroup_results$subgroup, subgroup_results$stratum, sep = ": ")
p_forest <- ggplot(subgroup_results, aes(OR, reorder(label, rev(seq_along(label))))) +
  geom_vline(xintercept = 1, linetype = 2, color = "#8B1A1A") +
  geom_errorbarh(aes(xmin = LCI, xmax = UCI), height = .16, color = "#8B1A1A") +
  geom_point(shape = 18, size = 3, color = "#8B1A1A") +
  scale_x_log10() + labs(x = "Odds ratio with 95% CI", y = NULL) + theme_classic(base_size = 10)
ggsave(file.path(out_dir, "Figure_subgroup_revised.png"), p_forest, width = 7.2, height = 7, dpi = 600)
ggsave(file.path(out_dir, "Figure_subgroup_revised.pdf"), p_forest, width = 7.2, height = 7)

sample_flow <- data.frame(
  population = c("Original merged sample", "Adults aged 20 years or older", "Adults with stroke status",
                 "Primary valid Day 1 sample", "Two day sensitivity sample",
                 "Primary sample with hsCRP available"),
  n = c(nrow(dat), sum(dat$age >= 20, na.rm = TRUE),
        sum(dat$age >= 20 & !is.na(dat$stroke), na.rm = TRUE), nrow(primary), nrow(two_day),
        sum(!is.na(primary$hscrp))),
  stroke_cases = c(sum(dat$stroke == 1, na.rm = TRUE), sum(dat$stroke == 1 & dat$age >= 20, na.rm = TRUE),
                   sum(dat$stroke == 1 & dat$age >= 20 & !is.na(dat$stroke), na.rm = TRUE),
                   sum(primary$stroke == 1, na.rm = TRUE),
                   sum(two_day$stroke == 1, na.rm = TRUE),
                   sum(primary$stroke == 1 & !is.na(primary$hscrp), na.rm = TRUE))
)
write.csv(sample_flow, file.path(out_dir, "sample_flow.csv"), row.names = FALSE)
saveRDS(primary, file.path(out_dir, "primary_day1_analysis_data.rds"))
saveRDS(two_day, file.path(out_dir, "sensitivity_2day_analysis_data.rds"))

writeLines(capture.output(sessionInfo()), file.path(out_dir, "sessionInfo.txt"))
cat("Revision analysis completed:", out_dir, "\n")
