suppressPackageStartupMessages(library(ggplot2))

out_dir <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/NHANES_revision"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

boxes <- data.frame(
  xmin = c(0.7, 1.25, 1.25, 0.70, 6.0, 6.0, 6.0),
  xmax = c(4.7, 4.15, 4.15, 4.70, 11.4, 11.4, 11.4),
  ymin = c(10.9, 8.75, 6.60, 4.00, 9.95, 7.80, 5.30),
  ymax = c(12.3, 9.50, 7.35, 5.40, 11.15, 9.00, 6.70),
  label = c(
    "Original merged sample\n7 cycles, 2005 to 2018\nN = 70,190",
    "N = 39,749",
    "N = 39,689",
    "Primary analytical sample\nValid Day 1 dietary recall\nN = 34,928",
    "Excluded: younger than 20 years\nn = 30,441",
    "Excluded: missing stroke history\nn = 60",
    "Excluded: missing Day 1 dietary recall\nor energy intake outside 500 to 8,000 kcal\nn = 4,761"
  ),
  type = c("main", "step", "step", "final", "exclude", "exclude", "exclude")
)

sens <- data.frame(
  xmin = 6.0, xmax = 11.4, ymin = 1.35, ymax = 2.60,
  label = "Sensitivity analysis sample\nComplete two day dietary recalls\nN = 30,743"
)

p <- ggplot() +
  geom_rect(data = boxes, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = "white", color = "black", linewidth = 0.65) +
  geom_text(data = boxes, aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = label),
            size = 4.15, lineheight = 1.12, family = "sans") +
  geom_rect(data = sens, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = "white", color = "black", linewidth = 0.65, linetype = "dashed") +
  geom_text(data = sens, aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = label),
            size = 4.0, lineheight = 1.12, family = "sans") +
  annotate("segment", x = 2.7, xend = 2.7, y = 10.9, yend = 9.55,
           linewidth = 0.65, arrow = arrow(length = unit(0.18, "cm"), type = "closed")) +
  annotate("segment", x = 2.7, xend = 2.7, y = 8.75, yend = 7.40,
           linewidth = 0.65, arrow = arrow(length = unit(0.18, "cm"), type = "closed")) +
  annotate("segment", x = 2.7, xend = 2.7, y = 6.60, yend = 5.45,
           linewidth = 0.65, arrow = arrow(length = unit(0.18, "cm"), type = "closed")) +
  annotate("segment", x = 2.7, xend = 6.0, y = 10.15, yend = 10.15,
           linewidth = 0.65, arrow = arrow(length = unit(0.18, "cm"), type = "closed")) +
  annotate("segment", x = 2.7, xend = 6.0, y = 8.25, yend = 8.25,
           linewidth = 0.65, arrow = arrow(length = unit(0.18, "cm"), type = "closed")) +
  annotate("segment", x = 2.7, xend = 6.0, y = 5.95, yend = 5.95,
           linewidth = 0.65, arrow = arrow(length = unit(0.18, "cm"), type = "closed")) +
  annotate("segment", x = 4.7, xend = 6.0, y = 4.70, yend = 2.60,
           linewidth = 0.55, linetype = "dashed",
           arrow = arrow(length = unit(0.16, "cm"), type = "closed")) +
  annotate("text", x = 8.7, y = 3.25, label = "Subset used for sensitivity analysis",
           size = 3.3, fontface = "italic") +
  coord_cartesian(xlim = c(0.2, 11.8), ylim = c(0.8, 12.7), clip = "off") +
  theme_void() +
  theme(plot.margin = margin(14, 14, 14, 14))

ggsave(file.path(out_dir, "Figure_flowchart_revised.png"), p,
       width = 9.2, height = 9.2, dpi = 600, bg = "white")
ggsave(file.path(out_dir, "Figure_flowchart_revised.tiff"), p,
       width = 9.2, height = 9.2, dpi = 600, compression = "lzw", bg = "white")
ggsave(file.path(out_dir, "Figure_flowchart_revised.pdf"), p,
       width = 9.2, height = 9.2, device = cairo_pdf, bg = "white")

cat("Flowchart files created in", out_dir, "\n")
