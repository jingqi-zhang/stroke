base_script <- "C:/Users/13918/Desktop/stoke/bulk/07_ML_GSE16561.R"
candidate_file <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/bulk_revision/training_only_selection/GSE16561_training_only_candidates.csv"
new_out <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/bulk_revision/GSE16561_training_model"

code <- readLines(base_script, warn = FALSE)
code <- sub(
  '^out_dir  <- file.path\\(dest_dir, "07_ML_GSE16561"\\)$',
  paste0('out_dir <- "', new_out, '"'), code
)
code <- sub(
  '^focus_genes <- c\\("TLR2", "TLR4", "HK2", "PTGS2", "TLR5"\\)$',
  paste0('focus_genes <- read.csv("', candidate_file,
         '", stringsAsFactors = FALSE)$Gene'), code
)
code <- gsub("5-gene logistic", "candidate logistic", code, fixed = TRUE)
code <- gsub("5-gene", "candidate", code, fixed = TRUE)
code <- gsub("focus-gene", "training-candidate", code, fixed = TRUE)
dir.create(new_out, recursive = TRUE, showWarnings = FALSE)
eval(parse(text = code), envir = globalenv())
