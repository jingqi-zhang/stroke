suppressPackageStartupMessages({
  cran_pkgs <- c(
    "ggplot2", "dplyr", "tibble", "tidyr", "glmnet",
    "randomForest", "pROC", "pheatmap", "scales"
  )
  bioc_pkgs <- c("Biobase", "GEOquery")

  ensure_cran <- function(pkg) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
      install.packages(pkg, repos = "https://cloud.r-project.org")
    }
    suppressPackageStartupMessages(library(pkg, character.only = TRUE))
  }

  ensure_bioc <- function(pkg) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
      if (!requireNamespace("BiocManager", quietly = TRUE)) {
        install.packages("BiocManager", repos = "https://cloud.r-project.org")
      }
      BiocManager::install(pkg, ask = FALSE, update = FALSE)
    }
    suppressPackageStartupMessages(library(pkg, character.only = TRUE))
  }

  invisible(lapply(cran_pkgs, ensure_cran))
  invisible(lapply(bioc_pkgs, ensure_bioc))
})

dest_dir  <- "C:/Users/13918/Desktop/stoke/bulk"
train_id  <- "GSE16561"
valid_id  <- "GSE58294"
out_dir   <- file.path(dest_dir, "08_external_validation_GSE58294")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

focus_genes <- c("TLR2", "TLR4", "HK2", "PTGS2", "TLR5")
set.seed(1234)

theme_cell <- function(base_size = 10) {
  ggplot2::theme_classic(base_size = base_size) %+replace%
    ggplot2::theme(
      plot.title = ggplot2::element_text(size = 11, face = "bold", hjust = 0.5),
      axis.title = ggplot2::element_text(size = 9, color = "black"),
      axis.text = ggplot2::element_text(size = 8, color = "black"),
      axis.line = ggplot2::element_line(linewidth = 0.4, color = "black"),
      axis.ticks = ggplot2::element_line(linewidth = 0.4, color = "black"),
      legend.title = ggplot2::element_text(size = 8),
      legend.text = ggplot2::element_text(size = 7),
      legend.key.size = grid::unit(0.35, "cm"),
      strip.background = ggplot2::element_rect(fill = "grey95", color = NA),
      strip.text = ggplot2::element_text(size = 8, face = "bold"),
      plot.margin = ggplot2::margin(8, 8, 8, 8)
    )
}

group_cols <- c("Control" = "#4DBBD5FF", "Stroke" = "#E64B35FF")
model_cols <- c(
  "5-gene logistic" = "#3C5488FF",
  "LASSO" = "#00A087FF",
  "Random forest" = "#F39B7FFF"
)
heat_cols <- colorRampPalette(c("#3C5488FF", "white", "#E64B35FF"))(100)

save_panel <- function(plot_obj, filename, width = 4.2, height = 3.6) {
  ggplot2::ggsave(
    file.path(out_dir, paste0(filename, ".pdf")),
    plot_obj, width = width, height = height, dpi = 300
  )
  ggplot2::ggsave(
    file.path(out_dir, paste0(filename, ".png")),
    plot_obj, width = width, height = height, dpi = 600
  )
}

identify_group <- function(pd) {
  priority_cols <- c("title", "source_name_ch1")
  for (col in priority_cols) {
    if (!col %in% colnames(pd)) next
    vals <- tolower(as.character(pd[[col]]))
    if (any(grepl("stroke", vals)) && any(grepl("control", vals))) {
      grp <- ifelse(grepl("stroke", vals), "Stroke", "Control")
      return(factor(grp, levels = c("Control", "Stroke")))
    }
  }

  for (col in colnames(pd)) {
    vals <- tolower(as.character(pd[[col]]))
    uvals <- unique(vals)
    if (length(uvals) < 2 || length(uvals) > 10) next
    has_stroke  <- any(grepl("stroke|ischemic|patient|case", uvals))
    has_control <- any(grepl("control|normal|healthy|non-stroke", uvals))
    if (has_stroke && has_control) {
      grp <- ifelse(grepl("stroke|ischemic|patient|case", vals), "Stroke", "Control")
      return(factor(grp, levels = c("Control", "Stroke")))
    }
  }
  stop("Cannot identify Stroke/Control grouping from phenoData.")
}

probe_to_symbol <- function(eset, dest_dir) {
  fd <- Biobase::fData(eset)
  sym_cols <- c(
    "Gene Symbol", "gene_assignment", "GENE_SYMBOL", "Symbol",
    "Gene symbol", "gene_symbol", "ILMN_Gene", "Gene.Symbol"
  )

  clean_symbol <- function(x, from_gene_assignment = FALSE) {
    x <- as.character(x)
    if (from_gene_assignment) {
      x <- vapply(strsplit(x, " // "), function(xx) {
        if (length(xx) >= 2) trimws(xx[2]) else NA_character_
      }, character(1))
    }
    x[x %in% c("", "---", "NA", "NULL")] <- NA_character_
    x <- vapply(strsplit(x, " */// *"), `[`, character(1), 1)
    x <- trimws(x)
    x[x == ""] <- NA_character_
    x
  }

  for (sc in sym_cols) {
    if (sc %in% colnames(fd)) {
      return(clean_symbol(fd[[sc]], from_gene_assignment = identical(sc, "gene_assignment")))
    }
  }

  gpl_id <- Biobase::annotation(eset)
  gpl_cache <- file.path(dest_dir, paste0(gpl_id, ".rds"))
  if (file.exists(gpl_cache)) {
    gpl <- readRDS(gpl_cache)
  } else {
    gpl <- GEOquery::getGEO(gpl_id, destdir = dest_dir)
    saveRDS(gpl, gpl_cache)
  }

  gpl_tab <- GEOquery::Table(gpl)
  for (sc in sym_cols) {
    if (sc %in% colnames(gpl_tab)) {
      mapping <- gpl_tab[, c("ID", sc)]
      colnames(mapping) <- c("probe", "symbol")
      mapping$symbol <- clean_symbol(mapping$symbol, from_gene_assignment = identical(sc, "gene_assignment"))
      idx <- match(rownames(Biobase::exprs(eset)), mapping$probe)
      return(mapping$symbol[idx])
    }
  }

  rownames(Biobase::exprs(eset))
}

collapse_to_gene <- function(expr, gene_symbols) {
  keep <- !is.na(gene_symbols) & gene_symbols != ""
  expr <- expr[keep, , drop = FALSE]
  gene_symbols <- gene_symbols[keep]

  sums <- rowsum(expr, group = gene_symbols, reorder = FALSE)
  counts <- as.numeric(table(gene_symbols)[rownames(sums)])
  sweep(sums, 1, counts, "/")
}

preprocess_dataset <- function(gse_id, dest_dir) {
  eset_obj <- readRDS(file.path(dest_dir, paste0(gse_id, "_matrix.rds")))
  eset <- if (is.list(eset_obj)) eset_obj[[1]] else eset_obj

  expr <- Biobase::exprs(eset)
  pd   <- Biobase::pData(eset)
  group <- identify_group(pd)
  names(group) <- colnames(expr)

  if (max(expr, na.rm = TRUE) > 50) {
    expr <- log2(expr + 1)
  }

  expr[is.infinite(expr)] <- NA_real_
  keep_rows <- rowMeans(is.na(expr)) < 0.5
  expr <- expr[keep_rows, , drop = FALSE]

  for (i in seq_len(nrow(expr))) {
    na_idx <- is.na(expr[i, ])
    if (any(na_idx)) {
      expr[i, na_idx] <- stats::median(expr[i, !na_idx], na.rm = TRUE)
    }
  }

  symbols <- probe_to_symbol(eset, dest_dir)
  symbols <- symbols[keep_rows]
  expr_gene <- collapse_to_gene(expr, symbols)

  list(
    expr_gene = expr_gene,
    group = factor(group[colnames(expr_gene)], levels = c("Control", "Stroke"))
  )
}

cat("\n========== 08 External validation ==========\n")

train_dat <- preprocess_dataset(train_id, dest_dir)
valid_dat <- preprocess_dataset(valid_id, dest_dir)

present_train <- intersect(focus_genes, rownames(train_dat$expr_gene))
present_valid <- intersect(focus_genes, rownames(valid_dat$expr_gene))
common_genes  <- intersect(present_train, present_valid)
missing_train <- setdiff(focus_genes, present_train)
missing_valid <- setdiff(focus_genes, present_valid)

if (length(common_genes) < 2) {
  stop("Too few focus genes shared between training and validation datasets.")
}

x_train <- t(train_dat$expr_gene[common_genes, , drop = FALSE])
x_valid <- t(valid_dat$expr_gene[common_genes, , drop = FALSE])
y_train <- train_dat$group[rownames(x_train)]
y_valid <- valid_dat$group[rownames(x_valid)]
y_train_num <- ifelse(y_train == "Stroke", 1, 0)

nfolds <- min(10, min(table(y_train)))
nfolds <- max(nfolds, 5)

cv_fit <- glmnet::cv.glmnet(
  x = x_train,
  y = y_train_num,
  family = "binomial",
  alpha = 1,
  nfolds = nfolds,
  type.measure = "auc"
)

coef_1se <- as.matrix(glmnet::coef.glmnet(cv_fit, s = "lambda.1se"))
coef_min <- as.matrix(glmnet::coef.glmnet(cv_fit, s = "lambda.min"))
lasso_lambda <- if (sum(coef_1se[-1, 1] != 0) >= 2) "lambda.1se" else "lambda.min"
coef_use <- if (lasso_lambda == "lambda.1se") coef_1se else coef_min
lasso_tbl <- tibble::tibble(
  Gene = rownames(coef_use),
  Coef = as.numeric(coef_use[, 1])
) %>%
  dplyr::filter(Gene != "(Intercept)")

rf_fit <- randomForest::randomForest(
  x = x_train,
  y = y_train,
  ntree = 1000,
  importance = TRUE
)
rf_imp <- randomForest::importance(rf_fit)
rf_col <- grep("MeanDecreaseGini|MeanDecreaseAccuracy", colnames(rf_imp), value = TRUE)[1]
rf_tbl <- tibble::tibble(
  Gene = rownames(rf_imp),
  Importance = rf_imp[, rf_col]
) %>%
  dplyr::arrange(dplyr::desc(Importance))

center <- apply(x_train, 2, mean)
scale_ <- apply(x_train, 2, stats::sd)
scale_[scale_ == 0 | is.na(scale_)] <- 1

x_train_scaled <- sweep(x_train, 2, center, "-")
x_train_scaled <- sweep(x_train_scaled, 2, scale_, "/")
x_valid_scaled <- sweep(x_valid, 2, center, "-")
x_valid_scaled <- sweep(x_valid_scaled, 2, scale_, "/")

safe_names <- make.names(colnames(x_train_scaled), unique = TRUE)
colnames(x_train_scaled) <- safe_names
colnames(x_valid_scaled) <- safe_names

glm_df <- as.data.frame(x_train_scaled)
glm_df$Class <- y_train_num
glm_fit <- suppressWarnings(
  stats::glm(stats::reformulate(safe_names, response = "Class"),
             data = glm_df, family = stats::binomial())
)

glm_coef <- stats::coef(glm_fit)
glm_coef <- glm_coef[setdiff(names(glm_coef), "(Intercept)")]
glm_coef_tbl <- data.frame(
  Safe = names(glm_coef),
  Coef = as.numeric(glm_coef),
  stringsAsFactors = FALSE
) %>%
  dplyr::left_join(
    data.frame(Gene = common_genes, Safe = safe_names, stringsAsFactors = FALSE),
    by = "Safe"
  ) %>%
  dplyr::arrange(Coef)

pred_valid <- data.frame(
  Sample = rownames(x_valid),
  Group = y_valid,
  Logistic = as.numeric(stats::predict(glm_fit, newdata = as.data.frame(x_valid_scaled), type = "response")),
  LASSO = as.numeric(stats::predict(cv_fit, newx = x_valid, s = lasso_lambda, type = "response")),
  RF = as.numeric(stats::predict(rf_fit, newdata = x_valid, type = "prob")[, "Stroke"]),
  check.names = FALSE
)

roc_glm <- pROC::roc(pred_valid$Group, pred_valid$Logistic,
                     levels = c("Control", "Stroke"), direction = "<", quiet = TRUE)
roc_lasso <- pROC::roc(pred_valid$Group, pred_valid$LASSO,
                       levels = c("Control", "Stroke"), direction = "<", quiet = TRUE)
roc_rf <- pROC::roc(pred_valid$Group, pred_valid$RF,
                    levels = c("Control", "Stroke"), direction = "<", quiet = TRUE)

roc_df <- dplyr::bind_rows(
  data.frame(
    FPR = 1 - roc_glm$specificities,
    TPR = roc_glm$sensitivities,
    Model = sprintf("5-gene logistic (AUC = %.3f)", as.numeric(pROC::auc(roc_glm)))
  ),
  data.frame(
    FPR = 1 - roc_lasso$specificities,
    TPR = roc_lasso$sensitivities,
    Model = sprintf("LASSO (AUC = %.3f)", as.numeric(pROC::auc(roc_lasso)))
  ),
  data.frame(
    FPR = 1 - roc_rf$specificities,
    TPR = roc_rf$sensitivities,
    Model = sprintf("Random forest (AUC = %.3f)", as.numeric(pROC::auc(roc_rf)))
  )
)

model_cols_named <- stats::setNames(
  c(model_cols["5-gene logistic"], model_cols["LASSO"], model_cols["Random forest"]),
  c(
    sprintf("5-gene logistic (AUC = %.3f)", as.numeric(pROC::auc(roc_glm))),
    sprintf("LASSO (AUC = %.3f)", as.numeric(pROC::auc(roc_lasso))),
    sprintf("Random forest (AUC = %.3f)", as.numeric(pROC::auc(roc_rf)))
  )
)

score_df <- pred_valid %>%
  tidyr::pivot_longer(
    cols = c("Logistic", "LASSO", "RF"),
    names_to = "Model",
    values_to = "Score"
  ) %>%
  dplyr::mutate(
    Model = dplyr::recode(
      Model,
      "Logistic" = "5-gene logistic",
      "LASSO" = "LASSO",
      "RF" = "Random forest"
    )
  )

expr_valid_focus <- valid_dat$expr_gene[common_genes, , drop = FALSE]
expr_valid_z <- t(scale(t(expr_valid_focus)))
anno_col <- data.frame(Group = y_valid, row.names = colnames(expr_valid_z))
anno_colors <- list(Group = group_cols)

box_df <- as.data.frame(t(expr_valid_focus)) %>%
  tibble::rownames_to_column("Sample") %>%
  dplyr::mutate(Group = y_valid[Sample]) %>%
  tidyr::pivot_longer(
    cols = dplyr::all_of(common_genes),
    names_to = "Gene",
    values_to = "Expression"
  )

deg_file <- file.path(dest_dir, paste0(valid_id, "_DEG_results.csv"))
if (!file.exists(deg_file)) {
  deg_file <- file.path(dest_dir, paste0(valid_id, "_DEG_sig.csv"))
}
deg_tbl <- read.csv(deg_file, stringsAsFactors = FALSE)
focus_deg_tbl <- deg_tbl %>%
  dplyr::filter(Gene %in% focus_genes) %>%
  dplyr::group_by(Gene) %>%
  dplyr::slice_min(adj.P.Val, n = 1, with_ties = FALSE) %>%
  dplyr::ungroup()

cv_df <- tibble::tibble(
  log_lambda = log(cv_fit$lambda),
  cvm = cv_fit$cvm,
  cvup = cv_fit$cvup,
  cvlo = cv_fit$cvlo
)

p_lasso_cv <- ggplot2::ggplot(cv_df, ggplot2::aes(x = log_lambda, y = cvm)) +
  ggplot2::geom_ribbon(ggplot2::aes(ymin = cvlo, ymax = cvup),
                       fill = "#D9D9D9", alpha = 0.6) +
  ggplot2::geom_line(color = "#3C5488FF", linewidth = 0.6) +
  ggplot2::geom_vline(xintercept = log(cv_fit$lambda.min), color = "#E64B35FF",
                      linetype = "dashed", linewidth = 0.4) +
  ggplot2::geom_vline(xintercept = log(cv_fit$lambda.1se), color = "#00A087FF",
                      linetype = "dashed", linewidth = 0.4) +
  ggplot2::labs(
    title = paste0(train_id, " LASSO CV"),
    x = "log(Lambda)",
    y = "Cross-validation error"
  ) +
  theme_cell()
save_panel(p_lasso_cv, paste0(valid_id, "_external_focus_lasso_cv"))

p_lasso_coef <- ggplot2::ggplot(
  lasso_tbl,
  ggplot2::aes(x = stats::reorder(Gene, Coef), y = Coef, fill = Coef > 0)
) +
  ggplot2::geom_col(width = 0.7, color = NA) +
  ggplot2::coord_flip() +
  ggplot2::scale_fill_manual(values = c("TRUE" = "#E64B35FF", "FALSE" = "#4DBBD5FF")) +
  ggplot2::labs(
    title = paste0(train_id, " focus-gene LASSO"),
    x = NULL,
    y = "Coefficient"
  ) +
  theme_cell() +
  ggplot2::theme(legend.position = "none")
save_panel(p_lasso_coef, paste0(valid_id, "_external_focus_lasso_coef"), width = 4.0, height = 3.2)

p_roc <- ggplot2::ggplot(roc_df, ggplot2::aes(x = FPR, y = TPR, color = Model)) +
  ggplot2::geom_line(linewidth = 0.9) +
  ggplot2::geom_abline(intercept = 0, slope = 1, linetype = "dashed",
                       color = "grey55", linewidth = 0.4) +
  ggplot2::scale_color_manual(values = model_cols_named) +
  ggplot2::labs(
    title = paste0(valid_id, " external ROC"),
    x = "1 - Specificity",
    y = "Sensitivity",
    color = NULL
  ) +
  theme_cell() +
  ggplot2::theme(legend.position = c(0.60, 0.22))
save_panel(p_roc, paste0(valid_id, "_external_focus_roc"))

p_score <- ggplot2::ggplot(score_df, ggplot2::aes(x = Group, y = Score, fill = Group)) +
  ggplot2::geom_boxplot(width = 0.65, linewidth = 0.3, outlier.shape = NA) +
  ggplot2::geom_jitter(width = 0.12, size = 0.7, alpha = 0.55, color = "black") +
  ggplot2::facet_wrap(~ Model, scales = "free_y", ncol = 3) +
  ggplot2::scale_fill_manual(values = group_cols) +
  ggplot2::labs(
    title = paste0(valid_id, " external prediction score"),
    x = NULL,
    y = "Predicted probability"
  ) +
  theme_cell() +
  ggplot2::theme(
    legend.position = "none",
    axis.text.x = ggplot2::element_text(angle = 20, hjust = 1)
  )
save_panel(p_score, paste0(valid_id, "_external_focus_score_boxplot"), width = 6.0, height = 3.2)

p_glm_coef <- ggplot2::ggplot(
  glm_coef_tbl,
  ggplot2::aes(x = stats::reorder(Gene, Coef), y = Coef, fill = Coef > 0)
) +
  ggplot2::geom_col(width = 0.7, color = NA) +
  ggplot2::coord_flip() +
  ggplot2::scale_fill_manual(values = c("TRUE" = "#E64B35FF", "FALSE" = "#4DBBD5FF")) +
  ggplot2::labs(
    title = paste0(train_id, " 5-gene logistic"),
    x = NULL,
    y = "Coefficient"
  ) +
  theme_cell() +
  ggplot2::theme(legend.position = "none")
save_panel(p_glm_coef, paste0(valid_id, "_external_focus_logistic_coef"), width = 4.0, height = 3.2)

p_rf <- ggplot2::ggplot(
  rf_tbl,
  ggplot2::aes(x = stats::reorder(Gene, Importance), y = Importance)
) +
  ggplot2::geom_col(fill = "#00A087FF", width = 0.7) +
  ggplot2::coord_flip() +
  ggplot2::labs(
    title = paste0(train_id, " RF importance"),
    x = NULL,
    y = rf_col
  ) +
  theme_cell()
save_panel(p_rf, paste0(valid_id, "_external_focus_rf_importance"), width = 4.0, height = 3.2)

grDevices::pdf(
  file.path(out_dir, paste0(valid_id, "_external_focus_heatmap.pdf")),
  width = 4.8, height = 4.6
)
pheatmap::pheatmap(
  expr_valid_z,
  color = heat_cols,
  border_color = NA,
  cluster_cols = TRUE,
  cluster_rows = FALSE,
  show_colnames = FALSE,
  annotation_col = anno_col,
  annotation_colors = anno_colors,
  fontsize_row = 9,
  main = paste0(valid_id, " focus-gene heatmap")
)
grDevices::dev.off()

grDevices::png(
  file.path(out_dir, paste0(valid_id, "_external_focus_heatmap.png")),
  width = 4.8, height = 4.6, units = "in", res = 600
)
pheatmap::pheatmap(
  expr_valid_z,
  color = heat_cols,
  border_color = NA,
  cluster_cols = TRUE,
  cluster_rows = FALSE,
  show_colnames = FALSE,
  annotation_col = anno_col,
  annotation_colors = anno_colors,
  fontsize_row = 9,
  main = paste0(valid_id, " focus-gene heatmap")
)
grDevices::dev.off()

p_box <- ggplot2::ggplot(box_df, ggplot2::aes(x = Group, y = Expression, fill = Group)) +
  ggplot2::geom_boxplot(width = 0.65, linewidth = 0.3, outlier.shape = NA) +
  ggplot2::geom_jitter(width = 0.12, size = 0.7, alpha = 0.55, color = "black") +
  ggplot2::facet_wrap(~ Gene, scales = "free_y", ncol = 2) +
  ggplot2::scale_fill_manual(values = group_cols) +
  ggplot2::labs(
    title = paste0(valid_id, " focus-gene expression"),
    x = NULL,
    y = expression(log[2]~Expression)
  ) +
  theme_cell() +
  ggplot2::theme(
    legend.position = "none",
    axis.text.x = ggplot2::element_text(angle = 20, hjust = 1)
  )
save_panel(p_box, paste0(valid_id, "_external_focus_boxplot"), width = 5.0, height = 5.0)

write.csv(
  data.frame(
    Gene = focus_genes,
    In_train = focus_genes %in% present_train,
    In_validation = focus_genes %in% present_valid
  ),
  file.path(out_dir, paste0(valid_id, "_external_focus_gene_check.csv")),
  row.names = FALSE
)
write.csv(focus_deg_tbl, file.path(out_dir, paste0(valid_id, "_external_focus_deg_stats.csv")), row.names = FALSE)
write.csv(lasso_tbl, file.path(out_dir, paste0(valid_id, "_external_focus_lasso_coef.csv")), row.names = FALSE)
write.csv(rf_tbl, file.path(out_dir, paste0(valid_id, "_external_focus_rf_importance.csv")), row.names = FALSE)
write.csv(glm_coef_tbl, file.path(out_dir, paste0(valid_id, "_external_focus_logistic_coef.csv")), row.names = FALSE)
write.csv(pred_valid, file.path(out_dir, paste0(valid_id, "_external_focus_predictions.csv")), row.names = FALSE)
write.csv(
  cbind(data.frame(Sample = rownames(x_valid), Group = y_valid, check.names = FALSE), as.data.frame(x_valid)),
  file.path(out_dir, paste0(valid_id, "_external_focus_expression_matrix.csv")),
  row.names = FALSE
)

cat("Common focus genes:", paste(common_genes, collapse = ", "), "\n")
if (length(missing_train) > 0) {
  cat("Missing in training:", paste(missing_train, collapse = ", "), "\n")
}
if (length(missing_valid) > 0) {
  cat("Missing in validation:", paste(missing_valid, collapse = ", "), "\n")
}
cat("External validation outputs:", out_dir, "\n")
