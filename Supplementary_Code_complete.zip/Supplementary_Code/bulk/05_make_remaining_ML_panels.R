suppressPackageStartupMessages({library(ggplot2); library(pROC); library(tidyr); library(dplyr)})
root <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/bulk_revision"
out <- file.path(root, "replacement_panels")
dir.create(out, recursive = TRUE, showWarnings = FALSE)
selected <- c("CD163", "PAK1", "FOS", "PTGS2", "HDAC4")
cols <- c(Control = "#62CFC3", Stroke = "#E91E63")
theme_pub <- theme_classic(base_size = 12) + theme(plot.title = element_text(hjust = 0.5, face = "bold"))
save_both <- function(p, stem, w, h) {
  ggsave(file.path(out, paste0(stem, ".png")), p, width = w, height = h, dpi = 600, bg = "white")
  ggsave(file.path(out, paste0(stem, ".pdf")), p, width = w, height = h, bg = "white")
}

# Panel A, training only evidence intersection
audit <- read.csv(file.path(root, "training_only_selection", "GSE16561_DEG_evidence_audit.csv"))
n_deg <- nrow(audit); n_gc <- sum(audit$In_GeneCards); n_gut <- sum(audit$In_gutMGene)
n_both <- sum(audit$In_GeneCards & audit$In_gutMGene)
theta <- seq(0, 2*pi, length.out = 300)
circles <- rbind(data.frame(x = 3.8 + 2.4*cos(theta), y = 3.7 + 1.9*sin(theta), Set = "GeneCards"),
                 data.frame(x = 6.2 + 2.4*cos(theta), y = 3.7 + 1.9*sin(theta), Set = "gutMGene"))
pA <- ggplot(circles, aes(x, y, group = Set, fill = Set, color = Set)) +
  geom_polygon(alpha = 0.55, linewidth = 0.7) + xlim(0, 10) + ylim(0, 7) + coord_fixed() + theme_void() +
  scale_fill_manual(values = c(GeneCards = "#E7A2B8", gutMGene = "#8ED9C4")) +
  scale_color_manual(values = c(GeneCards = "#B24C70", gutMGene = "#389B80")) +
  annotate("text", x = 3.0, y = 6.2, label = "GeneCards and\nGSE16561", color = "#A34E69", fontface = "bold", size = 5) +
  annotate("text", x = 7.0, y = 6.2, label = "gutMGene and\nGSE16561", color = "#328F77", fontface = "bold", size = 5) +
  annotate("text", x = 3.1, y = 3.7, label = n_gc - n_both, size = 7, fontface = "bold") +
  annotate("text", x = 6.9, y = 3.7, label = n_gut - n_both, size = 7, fontface = "bold") +
  annotate("text", x = 5.0, y = 3.7, label = n_both, size = 7, fontface = "bold") +
  annotate("text", x = 5.0, y = 1.0, label = paste0("15 training candidates\nGSE58294 not used for selection"), size = 4.6) +
  guides(fill = "none", color = "none")
save_both(pA, "Panel_A_training_only_intersection", 6.3, 4.5)

# Panel B, analysis flow
pB <- ggplot() + xlim(0, 10) + ylim(0, 10) + theme_void() +
  annotate("rect", xmin = 2, xmax = 8, ymin = 7.8, ymax = 9.3, fill = "#F3DCE3", color = "#A34E69") +
  annotate("text", x = 5, y = 8.55, label = "GSE16561 training set\n15 candidate genes", fontface = "bold", size = 5) +
  annotate("segment", x = 5, xend = 5, y = 7.7, yend = 6.4, arrow = arrow(length = unit(0.18, "cm")), linewidth = 0.8) +
  annotate("rect", xmin = 2, xmax = 8, ymin = 4.8, ymax = 6.3, fill = "#F8E9EE", color = "#A34E69") +
  annotate("text", x = 5, y = 5.55, label = "LASSO model training\n5 selected genes", fontface = "bold", size = 5) +
  annotate("segment", x = 5, xend = 5, y = 4.7, yend = 3.4, arrow = arrow(length = unit(0.18, "cm")), linewidth = 0.8) +
  annotate("rect", xmin = 2, xmax = 8, ymin = 1.6, ymax = 3.3, fill = "#DDF3ED", color = "#328F77") +
  annotate("text", x = 5, y = 2.45, label = "GSE58294 external validation\n23 controls and 23 stroke samples at 3 h", fontface = "bold", size = 3.9)
save_both(pB, "Panel_B_analysis_flow", 6.2, 5.5)

make_box <- function(path, title, stem) {
  x <- read.csv(path, check.names = FALSE)
  keep <- intersect(selected, colnames(x))
  z <- x[, c("Sample", "Group", keep), drop = FALSE] |>
    pivot_longer(cols = all_of(keep), names_to = "Gene", values_to = "Expression")
  z$Gene <- factor(z$Gene, levels = selected)
  tests <- z |> group_by(Gene) |> summarise(P = wilcox.test(Expression ~ Group)$p.value, .groups = "drop")
  tests$FDR <- p.adjust(tests$P, method = "BH")
  labs <- setNames(ifelse(tests$FDR < 0.001, "FDR < 0.001", sprintf("FDR = %.3f", tests$FDR)), tests$Gene)
  p <- ggplot(z, aes(Group, Expression, fill = Group)) +
    geom_boxplot(width = 0.62, outlier.shape = NA, linewidth = 0.4) +
    geom_jitter(width = 0.12, size = 0.8, alpha = 0.65) + facet_wrap(~Gene, scales = "free_y", ncol = 3,
      labeller = labeller(Gene = function(g) paste0(g, "\n", labs[g]))) +
    scale_fill_manual(values = cols) + labs(title = title, x = NULL, y = expression(log[2]~expression)) +
    theme_pub + theme(legend.position = "none", strip.background = element_rect(fill = "grey94", color = NA), strip.text = element_text(face = "bold"))
  save_both(p, stem, 7.2, 5.3)
  write.csv(tests, file.path(out, paste0(stem, "_statistics.csv")), row.names = FALSE)
}
make_box(file.path(root, "GSE16561_training_model", "GSE16561_ML_focus_expression_matrix.csv"),
         "GSE16561 selected gene expression", "Panel_C_GSE16561_selected_gene_expression")
make_box(file.path(root, "GSE58294_3h_external_validation", "GSE58294_external_focus_expression_matrix.csv"),
         "GSE58294 3 h selected gene expression", "Panel_F_GSE58294_3h_selected_gene_expression")

# Panel G, LASSO only internal validation ROC
pred <- read.csv(file.path(root, "GSE16561_training_model", "GSE16561_ML_focus_loocv_predictions.csv"))
r <- roc(pred$Group, pred$LASSO, levels = c("Control", "Stroke"), direction = "<", quiet = TRUE)
ci <- ci.auc(r); rd <- data.frame(FPR = 1-r$specificities, TPR = r$sensitivities)
pG <- ggplot(rd, aes(FPR, TPR)) + geom_abline(linetype = 2, color = "grey60") +
  geom_path(linewidth = 1.1, color = "#E91E63") + coord_equal() +
  annotate("text", x = 0.53, y = 0.20, hjust = 0, size = 3.6,
           label = sprintf("AUC = %.3f\n95%% CI %.3f to %.3f", as.numeric(auc(r)), ci[1], ci[3])) +
  labs(title = "GSE16561 LASSO leave one out validation", x = "1 minus specificity", y = "Sensitivity") + theme_pub
save_both(pG, "Panel_G_GSE16561_LASSO_LOOCV_ROC", 4.7, 4.4)
