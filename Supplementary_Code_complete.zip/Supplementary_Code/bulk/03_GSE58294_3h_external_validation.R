base_script <- "C:/Users/13918/Desktop/stoke/bulk/08_external_validation_GSE58294.R"
candidate_file <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/bulk_revision/training_only_selection/GSE16561_training_only_candidates.csv"
new_out <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/bulk_revision/GSE58294_3h_external_validation"

code <- readLines(base_script, warn = FALSE)
code <- sub(
  '^out_dir   <- file.path\\(dest_dir, "08_external_validation_GSE58294"\\)$',
  paste0('out_dir <- "', new_out, '"'), code
)
code <- sub(
  '^focus_genes <- c\\("TLR2", "TLR4", "HK2", "PTGS2", "TLR5"\\)$',
  paste0('focus_genes <- read.csv("', candidate_file,
         '", stringsAsFactors = FALSE)$Gene'), code
)
marker <- 'valid_dat <- preprocess_dataset(valid_id, dest_dir)'
insertion <- c(
  marker,
  'valid_eset <- readRDS(file.path(dest_dir, paste0(valid_id, "_matrix.rds")))[[1]]',
  'valid_pd <- Biobase::pData(valid_eset)',
  'valid_keep <- rownames(valid_pd)[valid_pd[["group:ch1"]] == "Control" | valid_pd[["time after stroke (h):ch1"]] == "3"]',
  'valid_keep <- intersect(valid_keep, colnames(valid_dat$expr_gene))',
  'valid_dat$expr_gene <- valid_dat$expr_gene[, valid_keep, drop = FALSE]',
  'valid_dat$group <- droplevels(valid_dat$group[valid_keep])',
  'write.csv(data.frame(Sample = valid_keep, Group = valid_dat$group, stringsAsFactors = FALSE), file.path(out_dir, "GSE58294_3h_validation_samples.csv"), row.names = FALSE)'
)
idx <- which(code == marker)
stopifnot(length(idx) == 1)
code <- append(code[-idx], insertion, after = idx - 1)
code <- gsub("5-gene logistic", "candidate logistic", code, fixed = TRUE)
code <- gsub("5-gene", "candidate", code, fixed = TRUE)
code <- gsub("focus-gene", "training-candidate", code, fixed = TRUE)
code <- gsub("GSE58294 external ROC", "GSE58294 3 h external ROC", code, fixed = TRUE)
dir.create(new_out, recursive = TRUE, showWarnings = FALSE)
eval(parse(text = code), envir = globalenv())
