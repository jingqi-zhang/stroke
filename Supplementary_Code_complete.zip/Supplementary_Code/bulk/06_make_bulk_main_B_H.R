suppressPackageStartupMessages({library(ggplot2); library(dplyr); library(tidyr); library(Biobase)})
root <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/bulk_revision"
out <- file.path(root, "replacement_panels")
dir.create(out, recursive = TRUE, showWarnings = FALSE)
theme_cell <- theme_classic(base_size = 11) + theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 12), axis.text = element_text(color = "black"))

# Panel B, GSE58294 PCA with time resolved groups
obj <- readRDS("C:/Users/13918/Desktop/stoke/bulk/GSE58294_matrix.rds")[[1]]
expr <- Biobase::exprs(obj); pd <- Biobase::pData(obj)
vars <- apply(expr, 1, var, na.rm = TRUE); top <- order(vars, decreasing = TRUE)[seq_len(min(5000, length(vars)))]
pc <- prcomp(t(expr[top, ]), center = TRUE, scale. = FALSE)
grp <- ifelse(pd[["group:ch1"]] == "Control", "Control", paste0("Stroke ", pd[["time after stroke (h):ch1"]], " h"))
grp <- factor(grp, levels = c("Control", "Stroke 3 h", "Stroke 5 h", "Stroke 24 h"))
pv <- 100 * pc$sdev^2 / sum(pc$sdev^2)
pdat <- data.frame(PC1 = pc$x[,1], PC2 = pc$x[,2], Group = grp)
pB <- ggplot(pdat, aes(PC1, PC2, color = Group, shape = Group)) +
  geom_point(size = 2.8, alpha = 0.9) +
  scale_color_manual(values = c("Control"="#55CFC1", "Stroke 3 h"="#E91E63", "Stroke 5 h"="#C44772", "Stroke 24 h"="#8F5878")) +
  scale_shape_manual(values = c(16, 17, 15, 3)) +
  labs(title = "GSE58294 PCA", x = sprintf("PC1 (%.1f%%)", pv[1]), y = sprintf("PC2 (%.1f%%)", pv[2]), color = NULL, shape = NULL) +
  theme_cell + theme(legend.position = c(0.82, 0.25), legend.background = element_rect(fill = "white", color = "grey80"))
ggsave(file.path(out, "Bulk_Panel_B_GSE58294_time_resolved_PCA.png"), pB, width = 5.2, height = 4.3, dpi = 600, bg = "white")
ggsave(file.path(out, "Bulk_Panel_B_GSE58294_time_resolved_PCA.pdf"), pB, width = 5.2, height = 4.3, bg = "white")

# Panel H, GSE16561 immune fractions with BH corrected Wilcoxon tests
ci <- read.csv("C:/Users/13918/Desktop/stoke/bulk/GSE16561_CIBERSORT_results.csv", check.names = FALSE)
meta <- c("P_value", "Correlation", "RMSE", "Sample", "Group")
cells <- setdiff(colnames(ci), meta)
long <- ci |> pivot_longer(cols = all_of(cells), names_to = "CellType", values_to = "Fraction")
keep <- long |> group_by(CellType) |> summarise(m = mean(Fraction, na.rm = TRUE), .groups = "drop") |> filter(m > 0.005) |> pull(CellType)
long <- long |> filter(CellType %in% keep)
stats <- long |> group_by(CellType) |> summarise(P = wilcox.test(Fraction ~ Group, exact = FALSE)$p.value, ymax = max(Fraction, na.rm = TRUE), .groups = "drop")
stats$FDR <- p.adjust(stats$P, method = "BH")
stats$Label <- ifelse(stats$FDR < 0.001, "***", ifelse(stats$FDR < 0.01, "**", ifelse(stats$FDR < 0.05, "*", "")))
stats$y <- pmin(1.02, stats$ymax + 0.045)
long$CellType <- factor(long$CellType, levels = keep); stats$CellType <- factor(stats$CellType, levels = keep)
pH <- ggplot(long, aes(CellType, Fraction, fill = Group)) +
  geom_boxplot(outlier.size = 0.5, linewidth = 0.3, width = 0.62, position = position_dodge(0.70)) +
  geom_text(data = stats, aes(CellType, y, label = Label), inherit.aes = FALSE, size = 3.5, fontface = "bold") +
  scale_fill_manual(values = c(Control = "#55CFC1", Stroke = "#E91E63")) +
  coord_cartesian(ylim = c(0, 1.06), clip = "off") +
  labs(title = "GSE16561, stroke versus control", x = NULL, y = "Cell fraction", fill = NULL) +
  theme_cell + theme(axis.text.x = element_text(angle = 48, hjust = 1, size = 7), legend.position = c(0.82, 0.78))
ggsave(file.path(out, "Bulk_Panel_H_GSE16561_immune_BH_corrected.png"), pH, width = 8.0, height = 4.5, dpi = 600, bg = "white")
ggsave(file.path(out, "Bulk_Panel_H_GSE16561_immune_BH_corrected.pdf"), pH, width = 8.0, height = 4.5, bg = "white")
write.csv(stats[, c("CellType", "P", "FDR", "Label")], file.path(out, "Bulk_Panel_H_immune_statistics.csv"), row.names = FALSE)
