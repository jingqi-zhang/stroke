suppressPackageStartupMessages({library(ggplot2); library(pROC)})
root <- "C:/Users/13918/Documents/Codex/2026-09-21/https-chatgpt-com-share-6ab117ed-8e88/outputs/bulk_revision"
out <- file.path(root, "replacement_panels")
dir.create(out, recursive = TRUE, showWarnings = FALSE)

theme_pub <- theme_classic(base_size = 12) + theme(plot.title = element_text(hjust = 0.5, face = "bold"))

deg <- read.csv(file.path(root, "GSE58294_corrected", "Stroke_3h_vs_Control_gene_results.csv"), check.names = FALSE)
deg$Status <- "Not significant"
deg$Status[deg$adj.P.Val < 0.05 & deg$logFC >= 0.5] <- "Up"
deg$Status[deg$adj.P.Val < 0.05 & deg$logFC <= -0.5] <- "Down"
deg$mlog10 <- -log10(pmax(deg$adj.P.Val, .Machine$double.xmin))
nup <- sum(deg$Status == "Up"); ndown <- sum(deg$Status == "Down")
p1 <- ggplot(deg, aes(logFC, mlog10, color = Status)) +
  geom_point(size = 0.7, alpha = 0.7) +
  geom_vline(xintercept = c(-0.5, 0.5), linetype = 2, color = "grey55") +
  geom_hline(yintercept = -log10(0.05), linetype = 2, color = "grey55") +
  scale_color_manual(values = c(Down = "#49C5B6", `Not significant` = "#D9E0E3", Up = "#E91E63")) +
  labs(title = "GSE58294, 3 h stroke versus control", x = expression(log[2]~fold~change),
       y = expression(-log[10]~adjusted~italic(P)),
       subtitle = sprintf("Up: %d    Down: %d", nup, ndown)) + theme_pub +
  theme(legend.position = "none")
ggsave(file.path(out, "GSE58294_3h_corrected_volcano.png"), p1, width = 5.2, height = 4.5, dpi = 600)
ggsave(file.path(out, "GSE58294_3h_corrected_volcano.pdf"), p1, width = 5.2, height = 4.5)

pred <- read.csv(file.path(root, "GSE58294_3h_external_validation", "GSE58294_external_focus_predictions.csv"))
r <- roc(pred$Group, pred$LASSO, levels = c("Control", "Stroke"), direction = "<", quiet = TRUE)
ci <- ci.auc(r)
roc_df <- data.frame(FPR = 1 - r$specificities, TPR = r$sensitivities)
p2 <- ggplot(roc_df, aes(FPR, TPR)) + geom_abline(linetype = 2, color = "grey60") +
  geom_path(linewidth = 1.1, color = "#00A087") + coord_equal() +
  annotate("text", x = 0.62, y = 0.18,
           label = sprintf("AUC = %.3f\n95%% CI %.3f to %.3f", as.numeric(auc(r)), ci[1], ci[3]),
           hjust = 0, size = 4) +
  labs(title = "GSE58294 3 h external validation", x = "1 minus specificity", y = "Sensitivity") + theme_pub
ggsave(file.path(out, "GSE58294_3h_LASSO_ROC.png"), p2, width = 4.7, height = 4.4, dpi = 600)
ggsave(file.path(out, "GSE58294_3h_LASSO_ROC.pdf"), p2, width = 4.7, height = 4.4)

coef <- read.csv(file.path(root, "GSE16561_training_model", "GSE16561_ML_focus_lasso_coef.csv"))
coef <- coef[coef$Coef != 0, ]
coef$Gene <- factor(coef$Gene, levels = coef$Gene[order(coef$Coef)])
p3 <- ggplot(coef, aes(Coef, Gene)) + geom_col(fill = "#E91E63", width = 0.65) +
  labs(title = "LASSO selected features in GSE16561", x = "Coefficient", y = NULL) + theme_pub
ggsave(file.path(out, "GSE16561_LASSO_selected_features.png"), p3, width = 4.7, height = 3.8, dpi = 600)
ggsave(file.path(out, "GSE16561_LASSO_selected_features.pdf"), p3, width = 4.7, height = 3.8)

write.csv(data.frame(Validation = "GSE58294 3 h", N_control = 23, N_stroke = 23,
                     AUC = as.numeric(auc(r)), CI_low = ci[1], CI_high = ci[3]),
          file.path(out, "replacement_panel_statistics.csv"), row.names = FALSE)
