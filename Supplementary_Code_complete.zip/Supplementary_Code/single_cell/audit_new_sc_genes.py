import scanpy as sc
import pandas as pd
import numpy as np
from scipy import sparse, stats
from pathlib import Path

src = r"C:\Users\13918\Desktop\stoke\GSE285659\adata_annotated.h5ad"
out = Path(r"C:\Users\13918\Documents\Codex\2026-09-21\https-chatgpt-com-share-6ab117ed-8e88\outputs\single_cell_revision")
out.mkdir(parents=True, exist_ok=True)
genes = ["CD163", "PAK1", "FOS", "PTGS2", "HDAC4"]

adata = sc.read_h5ad(src, backed="r")
mapping = dict(zip(adata.var["gene_name"].astype(str), adata.var_names))
ids = [mapping[g] for g in genes]

idx = adata.raw.var_names.get_indexer(ids)
if np.any(idx < 0):
    raise RuntimeError(f"Missing raw gene ids: {[ids[i] for i, v in enumerate(idx) if v < 0]}")
mat = adata.raw.X[:, idx]
if hasattr(mat, "to_memory"):
    mat = mat.to_memory()
if sparse.issparse(mat):
    mat = mat.toarray()
mat = np.asarray(mat)

meta = adata.obs[["sample", "condition", "donor", "cell_type"]].copy().reset_index(names="cell")
expr = pd.DataFrame(mat, columns=genes)
df = pd.concat([meta.reset_index(drop=True), expr], axis=1)

long = df.melt(id_vars=["cell", "sample", "condition", "donor", "cell_type"],
               value_vars=genes, var_name="gene", value_name="expression")
summary = (long.groupby(["donor", "condition", "cell_type", "gene"], observed=True)
           .agg(n_cells=("expression", "size"), mean_expression=("expression", "mean"),
                pct_expressing=("expression", lambda x: 100*np.mean(x > 0)))
           .reset_index())
summary.to_csv(out / "new_five_genes_donor_celltype_summary.csv", index=False)

rows=[]
for (ct,g), z in summary.groupby(["cell_type","gene"], observed=True):
    piv=z.pivot(index="donor", columns="condition", values="mean_expression")
    if not {"arterial","ischemic"}.issubset(piv.columns):
        continue
    piv=piv.dropna(); diff=piv["ischemic"]-piv["arterial"]
    try: p=stats.wilcoxon(piv["ischemic"],piv["arterial"],zero_method="wilcox",alternative="two-sided").pvalue
    except ValueError: p=np.nan
    rows.append({"cell_type":ct,"gene":g,"n_donor_pairs":len(piv),
                 "arterial_mean":piv["arterial"].mean(),"ischemic_mean":piv["ischemic"].mean(),
                 "mean_paired_difference":diff.mean(),"donors_higher_in_ischemic":int((diff>0).sum()),
                 "paired_wilcoxon_p":p})
audit=pd.DataFrame(rows)
audit["direction"] = np.where(audit["mean_paired_difference"]>0,"Higher in ischemic","Lower in ischemic")
audit.to_csv(out / "new_five_genes_paired_donor_audit.csv", index=False)

overall=(long.groupby(["condition","cell_type","gene"], observed=True)
         .agg(mean_expression=("expression","mean"),pct_expressing=("expression",lambda x:100*np.mean(x>0)),n_cells=("expression","size"))
         .reset_index())
overall.to_csv(out / "new_five_genes_celltype_descriptive.csv", index=False)

print(audit.to_string(index=False))
