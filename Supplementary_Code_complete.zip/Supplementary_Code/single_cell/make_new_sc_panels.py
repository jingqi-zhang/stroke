import scanpy as sc
import pandas as pd
import numpy as np
from scipy import sparse
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns

src = r"C:\Users\13918\Desktop\stoke\GSE285659\adata_annotated.h5ad"
out = Path(r"C:\Users\13918\Documents\Codex\2026-09-21\https-chatgpt-com-share-6ab117ed-8e88\outputs\single_cell_revision\replacement_panels")
out.mkdir(parents=True, exist_ok=True)
genes = ["CD163", "PAK1", "FOS", "PTGS2", "HDAC4"]
ct_order = ["CD14 Mono","CD16 Mono","cDC","CD4 T","Naive CD4 T","CD8 T","NK","B cell","Platelet"]
palette = {"CD14 Mono":"#5B2CDE","CD16 Mono":"#8047F5","cDC":"#B87700","CD4 T":"#D92D3A","Naive CD4 T":"#E66C85","CD8 T":"#48A9D8","NK":"#35A853","B cell":"#2A4A9B","Platelet":"#708B8D"}
cond = {"arterial":"#4DBBD5", "ischemic":"#D7263D"}
plt.rcParams.update({"font.family":"Arial","font.size":10,"axes.titlesize":12,"axes.titleweight":"bold","axes.labelsize":10,"pdf.fonttype":42,"ps.fonttype":42})

adata = sc.read_h5ad(src, backed="r")
mapping = dict(zip(adata.var["gene_name"].astype(str), adata.var_names))
ids = [mapping[g] for g in genes]
idx = adata.raw.var_names.get_indexer(ids)
mat = adata.raw.X[:, idx]
if hasattr(mat, "to_memory"): mat = mat.to_memory()
if sparse.issparse(mat): mat = mat.toarray()
mat = np.asarray(mat)
meta = adata.obs[["sample","condition","donor","cell_type"]].reset_index(drop=True)
expr = pd.DataFrame(mat, columns=genes)
df = pd.concat([meta, expr], axis=1)

# SC Panel E, dot plot
rows=[]
for ct in ct_order:
    z=df[df.cell_type==ct]
    for g in genes:
        rows.append([ct,g,z[g].mean(),100*(z[g]>0).mean()])
dot=pd.DataFrame(rows,columns=["cell_type","gene","mean","pct"])
dot["scaled"] = dot.groupby("gene")["mean"].transform(lambda x:(x-x.min())/(x.max()-x.min()+1e-12))
fig,ax=plt.subplots(figsize=(5.7,3.8))
for _,r in dot.iterrows():
    ax.scatter(genes.index(r.gene),ct_order.index(r.cell_type),s=10+3.0*r.pct,c=[[plt.cm.RdBu_r(r.scaled)]],edgecolors="grey",linewidths=.35)
ax.set_xticks(range(len(genes)),genes,rotation=45,ha="right"); ax.set_yticks(range(len(ct_order)),ct_order); ax.invert_yaxis()
ax.set_title("Selected genes across cell types"); ax.set_xlabel(""); ax.set_ylabel("")
for s in [20,40,60]: ax.scatter([],[],s=10+3*s,c="grey",alpha=.6,label=f"{s}%")
ax.legend(title="Cells expressing",bbox_to_anchor=(1.02,1),loc="upper left",frameon=False)
fig.tight_layout(); fig.savefig(out/"SC_Panel_E_new_five_gene_dotplot.pdf",bbox_inches="tight"); fig.savefig(out/"SC_Panel_E_new_five_gene_dotplot.png",dpi=600,bbox_inches="tight"); plt.close(fig)
dot.to_csv(out/"SC_Panel_E_dotplot_data.csv",index=False)

# SC Panel F, donor aware mean expression by cell type
agg=(df.melt(id_vars=["donor","condition","cell_type"],value_vars=genes,var_name="gene",value_name="expression")
     .groupby(["donor","condition","cell_type","gene"],observed=True).expression.mean().reset_index())
fig,axes=plt.subplots(1,5,figsize=(14,3.3),sharex=False)
for ax,g in zip(axes,genes):
    z=agg[agg.gene==g]
    sns.barplot(data=z,x="cell_type",y="expression",order=ct_order,palette=palette,errorbar="se",ax=ax,hue="cell_type",legend=False)
    sns.stripplot(data=z,x="cell_type",y="expression",order=ct_order,color="black",size=2.5,jitter=.08,ax=ax)
    ax.set_title(g); ax.set_xlabel(""); ax.set_ylabel("Mean expression" if g==genes[0] else ""); ax.tick_params(axis="x",rotation=55,labelsize=7)
    sns.despine(ax=ax)
fig.tight_layout(); fig.savefig(out/"SC_Panel_F_new_five_gene_celltype_expression.pdf",bbox_inches="tight"); fig.savefig(out/"SC_Panel_F_new_five_gene_celltype_expression.png",dpi=600,bbox_inches="tight"); plt.close(fig)

# SC2 Panel C, descriptive five gene expression score on UMAP
score=mat.mean(axis=1); score=(score-np.mean(score))/(np.std(score)+1e-12)
umap=np.asarray(adata.obsm["X_umap"])
lo,hi=np.quantile(score,[.02,.98])
fig,ax=plt.subplots(figsize=(4.7,4.2))
scat=ax.scatter(umap[:,0],umap[:,1],c=np.clip(score,lo,hi),s=.35,cmap="RdBu_r",rasterized=True)
ax.set_title("Five gene expression score"); ax.set_xlabel("UMAP 1"); ax.set_ylabel("UMAP 2"); ax.set_xticks([]); ax.set_yticks([]); plt.colorbar(scat,ax=ax,fraction=.045,pad=.02,label="Standardized score")
fig.tight_layout(); fig.savefig(out/"SC2_Panel_C_new_five_gene_score_UMAP.pdf",bbox_inches="tight"); fig.savefig(out/"SC2_Panel_C_new_five_gene_score_UMAP.png",dpi=600,bbox_inches="tight"); plt.close(fig)

# SC2 Panel D, paired donor summaries in myeloid cell types
df["five_gene_score"]=score
myz=(df[df.cell_type.isin(["CD14 Mono","CD16 Mono","cDC"])]
     .groupby(["donor","condition","cell_type"],observed=True).five_gene_score.mean().reset_index())
fig,axes=plt.subplots(1,3,figsize=(8.2,3.1),sharey=True)
for ax,ct in zip(axes,["CD14 Mono","CD16 Mono","cDC"]):
    z=myz[myz.cell_type==ct]
    for donor,d in z.groupby("donor"):
        d=d.set_index("condition").reindex(["arterial","ischemic"])
        ax.plot([0,1],d.five_gene_score,color="grey",lw=1,alpha=.8); ax.scatter([0,1],d.five_gene_score,c=[cond["arterial"],cond["ischemic"]],s=36,zorder=3)
    ax.set_xticks([0,1],["Arterial","Ischemic"],rotation=20); ax.set_title(ct); ax.axhline(0,color="grey",ls="--",lw=.6); sns.despine(ax=ax)
axes[0].set_ylabel("Mean standardized score"); fig.suptitle("Paired donor five gene expression score",fontweight="bold",y=1.02)
fig.tight_layout(); fig.savefig(out/"SC2_Panel_D_paired_donor_five_gene_score.pdf",bbox_inches="tight"); fig.savefig(out/"SC2_Panel_D_paired_donor_five_gene_score.png",dpi=600,bbox_inches="tight"); plt.close(fig)
myz.to_csv(out/"SC2_Panel_D_paired_score_data.csv",index=False)
print(out)
