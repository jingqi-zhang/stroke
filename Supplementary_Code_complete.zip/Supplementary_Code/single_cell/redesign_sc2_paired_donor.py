import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from pathlib import Path

root = Path(r"C:\Users\13918\Documents\Codex\2026-09-21\https-chatgpt-com-share-6ab117ed-8e88")
panel_dir = root / "outputs" / "single_cell_revision" / "replacement_panels"
data = pd.read_csv(panel_dir / "SC2_Panel_D_paired_score_data.csv")
pdf = panel_dir / "SC2_Panel_D_paired_donor_five_gene_score.pdf"
png = panel_dir / "SC2_Panel_D_paired_donor_five_gene_score.png"

plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 10,
    "axes.titlesize": 11.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

condition_colors = {"arterial": "#58B6D0", "ischemic": "#B52B30"}
donor_styles = {
    1: ("o", "-"),
    2: ("s", "--"),
    3: ("^", ":"),
}
cell_types = ["CD14 Mono", "CD16 Mono", "cDC"]

fig, axes = plt.subplots(1, 3, figsize=(7.15, 3.35), sharey=True)
for ax, cell_type in zip(axes, cell_types):
    subset = data[data["cell_type"] == cell_type]
    ax.set_facecolor("#FBFBFB")
    for donor in [1, 2, 3]:
        pair = subset[subset["donor"] == donor].set_index("condition").reindex(["arterial", "ischemic"])
        values = pair["five_gene_score"].to_numpy()
        marker, line_style = donor_styles[donor]
        ax.plot([0, 1], values, color="#747474", linestyle=line_style, linewidth=1.25, zorder=1)
        ax.scatter(0, values[0], s=55, marker=marker, facecolor=condition_colors["arterial"], edgecolor="white", linewidth=0.8, zorder=3)
        ax.scatter(1, values[1], s=55, marker=marker, facecolor=condition_colors["ischemic"], edgecolor="white", linewidth=0.8, zorder=3)

    ax.axhline(0, color="#969696", linestyle=(0, (3, 3)), linewidth=0.7, zorder=0)
    ax.set_xlim(-0.18, 1.18)
    ax.set_ylim(-0.13, 1.52)
    ax.set_xticks([0, 1], ["Arterial", "Ischemic"])
    ax.set_title(cell_type, pad=9)
    ax.grid(axis="y", color="#E7E7E7", linewidth=0.65)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(0.8)
    ax.spines["bottom"].set_linewidth(0.8)
    ax.tick_params(axis="both", width=0.8, length=3.5, labelsize=9.5)

axes[0].set_ylabel("Mean standardized score", labelpad=8)
for ax in axes[1:]:
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", left=False)

handles = [
    Line2D([0], [0], color="#747474", linestyle=donor_styles[d][1], marker=donor_styles[d][0],
           markerfacecolor="white", markeredgecolor="#747474", markersize=6, linewidth=1.25,
           label=f"Donor {d}")
    for d in [1, 2, 3]
]
fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, 1.005), ncol=3,
           frameon=False, handlelength=2.2, columnspacing=2.2, fontsize=9.2)
fig.subplots_adjust(left=0.10, right=0.99, bottom=0.17, top=0.78, wspace=0.13)
fig.savefig(pdf, bbox_inches="tight")
fig.savefig(png, dpi=600, bbox_inches="tight")
print(pdf)
