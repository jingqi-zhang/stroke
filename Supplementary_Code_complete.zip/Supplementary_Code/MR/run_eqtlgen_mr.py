import csv
import gzip
import math
from pathlib import Path

ROOT = Path(r"C:\Users\13918\Documents\Codex\2026-09-21\https-chatgpt-com-share-6ab117ed-8e88")
OUT = ROOT / "outputs" / "MR_revision"
TARGET = OUT / "04_eQTLGen_target_gene_significant_cis_eqtls.csv"
AF_FILE = ROOT / "work" / "eqtlgen_allele_frequency.txt.gz"
GWAS = Path(r"C:\Users\13918\Desktop\stoke\MR\29531354-GCST006908-HP_0002140.h.tsv.gz")
GENES = ["CD163", "PAK1", "FOS", "PTGS2", "HDAC4"]

rows = list(csv.DictReader(TARGET.open(encoding="utf-8-sig")))
lead = {}
for gene in GENES:
    candidates = [r for r in rows if r["GeneSymbol"] == gene]
    lead[gene] = min(candidates, key=lambda r: float(r["Pvalue"]))

wanted = {r["SNP"] for r in lead.values()}
af = {}
with gzip.open(AF_FILE, "rt", encoding="utf-8") as handle:
    reader = csv.DictReader(handle, delimiter="\t")
    for row in reader:
        if row["SNP"] in wanted:
            af[row["SNP"]] = row
            if len(af) == len(wanted):
                break

outcome = {}
with gzip.open(GWAS, "rt", encoding="utf-8") as handle:
    reader = csv.DictReader(handle, delimiter="\t")
    for row in reader:
        if row["hm_rsid"] in wanted:
            outcome[row["hm_rsid"]] = row
            if len(outcome) == len(wanted):
                break

results = []
for gene in GENES:
    e = lead[gene]
    snp = e["SNP"]
    a = af.get(snp)
    o = outcome.get(snp)
    base = {"gene": gene, "SNP": snp}
    if not a:
        results.append({**base, "status": "allele_frequency_missing"})
        continue
    if not o:
        results.append({**base, "status": "outcome_snp_missing"})
        continue
    assessed = e["AssessedAllele"].upper()
    other = e["OtherAllele"].upper()
    allele_b = a["AlleleB"].upper()
    p_b = float(a["AlleleB_all"])
    if assessed == allele_b:
        eaf = p_b
    elif other == allele_b:
        eaf = 1 - p_b
    else:
        results.append({**base, "status": "eqtl_af_allele_mismatch"})
        continue
    z = float(e["Zscore"])
    n = int(e["NrSamples"])
    denom = math.sqrt(2 * eaf * (1 - eaf) * (n + z * z))
    bx = z / denom
    sex = 1 / denom
    ea_o = o["hm_effect_allele"].upper()
    oa_o = o["hm_other_allele"].upper()
    if assessed == ea_o and other == oa_o:
        sign, align = 1, "match"
    elif assessed == oa_o and other == ea_o:
        sign, align = -1, "flip"
    else:
        results.append({**base, "status": "outcome_allele_mismatch"})
        continue
    by = sign * float(o["hm_beta"])
    sey = float(o["standard_error"])
    beta = by / bx
    se = sey / abs(bx)
    zmr = beta / se
    pmr = math.erfc(abs(zmr) / math.sqrt(2))
    results.append({
        **base,
        "effect_allele_exposure": assessed,
        "other_allele_exposure": other,
        "eaf_exposure": eaf,
        "n_exposure": n,
        "beta_exposure_standardized": bx,
        "se_exposure_standardized": sex,
        "pval_exposure": float(e["Pvalue"]),
        "F_stat": z * z,
        "beta_outcome_harmonised": by,
        "se_outcome": sey,
        "pval_outcome": float(o["p_value"]),
        "method": "Wald ratio",
        "beta_mr": beta,
        "se_mr": se,
        "pval_mr": pmr,
        "OR": math.exp(beta),
        "OR_lci95": math.exp(beta - 1.96 * se),
        "OR_uci95": math.exp(beta + 1.96 * se),
        "alignment": align,
        "status": "analysed",
    })

fields = sorted({k for r in results for k in r})
with (OUT / "05_eQTLGen_new_five_genes_MR_Wald_results.csv").open("w", newline="", encoding="utf-8-sig") as handle:
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    writer.writerows(results)

with (OUT / "06_eQTLGen_MR_summary.txt").open("w", encoding="utf-8") as handle:
    handle.write("Exposure source: eQTLGen Phase I significant cis eQTLs, whole blood and PBMC meta-analysis, up to 31,684 participants.\n")
    handle.write("Outcome source: MEGASTROKE GCST006908, ischemic stroke, 34,217 cases and 406,111 controls of European ancestry.\n")
    handle.write("Effect scale: odds ratio for ischemic stroke per genetically predicted 1 SD higher gene expression.\n")
    handle.write("Method: one lead cis eQTL per gene and Wald ratio.\n")
    handle.write("Interpretation constraint: single variant estimates do not permit heterogeneity, horizontal pleiotropy, or MR Egger tests. Colocalization was not performed.\n\n")
    for r in results:
        if r["status"] == "analysed":
            handle.write(f"{r['gene']}: OR {r['OR']:.3f}, 95% CI {r['OR_lci95']:.3f} to {r['OR_uci95']:.3f}, P {r['pval_mr']:.4g}, F {r['F_stat']:.1f}.\n")
        else:
            handle.write(f"{r['gene']}: {r['status']}.\n")

for r in results:
    print(r)
