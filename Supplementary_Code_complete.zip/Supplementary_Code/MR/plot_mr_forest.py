import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(r"C:\Users\13918\Documents\Codex\2026-09-21\https-chatgpt-com-share-6ab117ed-8e88")
SRC = ROOT / "outputs" / "MR_revision" / "05_eQTLGen_new_five_genes_MR_Wald_results.csv"
PDF = ROOT / "outputs" / "MR_revision" / "MR_new_five_genes_eQTLGen_forest.pdf"
PNG = ROOT / "work" / "MR_new_five_genes_eQTLGen_forest_QA.png"

rows = list(csv.DictReader(SRC.open(encoding="utf-8-sig")))
order = ["CD163", "PAK1", "FOS", "PTGS2", "HDAC4"]
rows = sorted(rows, key=lambda r: order.index(r["gene"]))

orv = np.array([float(r["OR"]) for r in rows])
lo = np.array([float(r["OR_lci95"]) for r in rows])
hi = np.array([float(r["OR_uci95"]) for r in rows])
y = np.arange(len(rows))[::-1]

fig = plt.figure(figsize=(9.2, 4.35))
gs = fig.add_gridspec(1, 3, width_ratios=[1.15, 2.7, 2.25], wspace=0.04)
ax_l = fig.add_subplot(gs[0, 0])
ax = fig.add_subplot(gs[0, 1], sharey=ax_l)
ax_r = fig.add_subplot(gs[0, 2], sharey=ax_l)

red = "#9E292B"
text = "#202020"
for a in (ax_l, ax_r):
    a.set_xlim(0, 1)
    a.set_ylim(-0.8, len(rows) - 0.2)
    a.axis("off")

ax_l.text(0.02, len(rows) - 0.05, "Gene", fontsize=12, fontweight="bold", color=red, va="bottom")
ax_r.text(0.02, len(rows) - 0.05, "OR (95% CI)", fontsize=12, fontweight="bold", color=red, va="bottom")
ax_r.text(0.88, len(rows) - 0.05, "P value", fontsize=12, fontweight="bold", color=red, va="bottom", ha="right")

for yi, r in zip(y, rows):
    ax_l.text(0.02, yi, r["gene"], fontsize=11.5, color=text, va="center")
    ax_r.text(0.02, yi, f"{float(r['OR']):.2f} ({float(r['OR_lci95']):.2f} to {float(r['OR_uci95']):.2f})", fontsize=10.7, color=text, va="center")
    ax_r.text(0.88, yi, f"{float(r['pval_mr']):.3f}", fontsize=10.7, color=text, va="center", ha="right")

ax.errorbar(orv, y, xerr=[orv - lo, hi - orv], fmt="D", ms=6.2, color=red, ecolor=red, elinewidth=1.5, capsize=4, capthick=1.3)
ax.axvline(1, color=red, linestyle=(0, (4, 4)), linewidth=1.2)
ax.set_xscale("log")
ax.set_xlim(0.75, 2.05)
ax.set_ylim(-0.8, len(rows) - 0.2)
ax.set_yticks([])
ax.set_xticks([0.8, 1.0, 1.5, 2.0])
ax.set_xticklabels(["0.8", "1.0", "1.5", "2.0"], fontsize=10.5)
ax.set_xlabel("Odds ratio for ischemic stroke", fontsize=11.5, labelpad=8)
ax.grid(axis="x", color="#E6E6E6", linewidth=0.8)
for spine in ["top", "left", "right"]:
    ax.spines[spine].set_visible(False)
ax.spines["bottom"].set_color("#555555")

fig.subplots_adjust(top=0.92, bottom=0.18)
fig.savefig(PDF, bbox_inches="tight")
fig.savefig(PNG, dpi=220, bbox_inches="tight")
print(PDF)
