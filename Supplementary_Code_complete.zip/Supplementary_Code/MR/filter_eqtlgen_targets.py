import csv
import gzip
from pathlib import Path

root = Path(r"C:\Users\13918\Documents\Codex\2026-09-21\https-chatgpt-com-share-6ab117ed-8e88")
src = root / "work" / "eqtlgen_significant_cis_eqtl.txt.gz"
out = root / "outputs" / "MR_revision" / "04_eQTLGen_target_gene_significant_cis_eqtls.csv"
genes = {"CD163", "PAK1", "FOS", "PTGS2", "HDAC4"}
counts = {g: 0 for g in genes}
best = {}

with gzip.open(src, "rt", encoding="utf-8") as fin, out.open("w", newline="", encoding="utf-8-sig") as fout:
    reader = csv.DictReader(fin, delimiter="\t")
    writer = csv.DictWriter(fout, fieldnames=reader.fieldnames)
    writer.writeheader()
    for row in reader:
        gene = row["GeneSymbol"]
        if gene not in genes:
            continue
        writer.writerow(row)
        counts[gene] += 1
        p = float(row["Pvalue"])
        if gene not in best or p < float(best[gene]["Pvalue"]):
            best[gene] = row

print("counts", counts)
for gene in sorted(genes):
    print(gene, best.get(gene))
