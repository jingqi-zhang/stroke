from pathlib import Path
import csv, json
from collections import defaultdict
ROOT=Path(r'C:\Users\13918\Documents\Codex\2026-09-21\https-chatgpt-com-share-6ab117ed-8e88')
OUT=ROOT/'outputs/complete_revision/evidence'
def read(p):
 with open(p,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
genes=['CD163','PAK1','FOS','PTGS2','HDAC4']
records=[]
for fn,source in [('Gut Microbe-Gene.csv','Gut Microbe (ID)'),('Microbial metabolite-Gene.csv','Metabolite (ID)')]:
 for raw in read(Path(r'C:\Users\13918\Desktop\stoke\gut')/fn):
  r={k.strip():v.strip() for k,v in raw.items()}
  g=r.get('Gene') or r.get('Gene Symbol')
  if g in genes: records.append(dict(source=r[source],gene=g,alteration=r['Alteration'],evidence=r['Evidence'],host=r['Host Species'],evidence_number=r['Evidence Number']))
write('gutMGene_complete_records.csv',records)
agg=read(ROOT/'outputs/single_cell_revision/new_five_genes_donor_celltype_summary.csv')
counts={(r['donor'],r['condition'],r['cell_type']):int(r['n_cells']) for r in agg}
totals=defaultdict(int)
for (dn,c,ct),n in counts.items():totals[dn,c]+=n
donors=[]
for (dn,c,ct),n in sorted(counts.items()):donors.append(dict(donor=dn,condition=c,cell_type=ct,n_cells=n,total_cells=totals[dn,c],percent=100*n/totals[dn,c]))
write('donor_cell_proportions.csv',donors)
paired=[]
for ct in sorted({ct for dn,c,ct in counts}):
 for dn in ['1','2','3']:
  na=counts[dn,'arterial',ct]; ni=counts[dn,'ischemic',ct]
  a=100*na/totals[dn,'arterial'];i=100*ni/totals[dn,'ischemic']
  paired.append(dict(cell_type=ct,donor=dn,arterial_percent=a,ischemic_percent=i,difference_percentage_points=i-a))
write('paired_cell_proportions.csv',paired)
scores=read(ROOT/'outputs/single_cell_revision/replacement_panels/SC2_Panel_D_paired_score_data.csv')
ds={(r['cell_type'],r['donor'],r['condition']):float(r['five_gene_score']) for r in scores}
pairedscore=[]
for ct in ['CD14 Mono','CD16 Mono','cDC']:
 for dn in ['1','2','3']:
  a=ds[ct,dn,'arterial'];i=ds[ct,dn,'ischemic']
  pairedscore.append(dict(cell_type=ct,donor=dn,arterial=a,ischemic=i,difference=i-a))
write('paired_scores.csv',pairedscore)
temporal=[]
for tm in ['3','5','24']:
 for r in read(ROOT/f'outputs/bulk_revision/GSE58294_corrected/Stroke_{tm}h_vs_Control_gene_results.csv'):
  if r['Gene'] in genes: temporal.append(dict(gene=r['Gene'],time=tm,logFC=r['logFC'],FDR=r['adj.P.Val']))
write('gene_time_specific_contrasts.csv',temporal)
print('gutMGene',records)
print('total cells',sum(totals.values()),'sample totals',dict(totals))
print('mean paired score differences',{ct:sum(r['difference'] for r in pairedscore if r['cell_type']==ct)/3 for ct in ['CD14 Mono','CD16 Mono','cDC']})
print('time specific',temporal)
